# Collab Workspace – Server (Week 1)

    npm install
    cp .env.example .env     # set real secrets
    npm run dev              # needs Node 20.6+ and a running MongoDB

## Endpoints
| Method | Path | Access |
|---|---|---|
| POST | /api/auth/register, /login, /refresh, /logout | public |
| GET | /api/auth/me | auth |
| POST | /api/workspaces | auth |
| GET | /api/workspaces | auth |
| GET | /api/workspaces/:id | viewer+ |
| PATCH / DELETE | /api/workspaces/:id | admin (delete: owner only) |
| POST | /api/workspaces/:id/invites | admin |
| DELETE | /api/workspaces/:id/invites/:inviteId | admin |
| POST | /api/workspaces/invites/accept `{token}` | auth (email must match invite) |
| PATCH | /api/workspaces/:id/members/:userId `{role}` | admin |
| DELETE | /api/workspaces/:id/members/:userId | admin, or self-leave |

Send `Authorization: Bearer <accessToken>`. The refresh token lives in an httpOnly cookie.
