import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { requireWorkspaceRole as role } from '../middleware/workspace.js';
import { validate } from '../middleware/validate.js';
import * as c from '../controllers/workspace.controller.js';
import * as b from '../controllers/board.controller.js';

const r = Router();
r.use(requireAuth);

r.post('/', validate(c.createSchema), c.create);
r.get('/', c.listMine);
r.post('/invites/accept', validate(c.acceptSchema), c.acceptInvite); // must precede /:workspaceId

r.get('/:workspaceId', role('viewer'), c.getOne);
r.get('/:workspaceId/boards', role('viewer'), b.listBoards);
r.post('/:workspaceId/boards', role('member'), validate(b.boardSchema), b.createBoard);
r.patch('/:workspaceId', role('admin'), validate(c.updateSchema), c.update);
r.delete('/:workspaceId', role('admin'), c.remove);

r.post('/:workspaceId/invites', role('admin'), validate(c.inviteSchema), c.invite);
r.delete('/:workspaceId/invites/:inviteId', role('admin'), c.revokeInvite);

r.patch('/:workspaceId/members/:userId', role('admin'), validate(c.roleSchema), c.updateMemberRole);
r.delete('/:workspaceId/members/:userId', role('viewer'), c.removeMember); // self-leave or admin remove

export default r;
