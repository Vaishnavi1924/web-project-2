import { z } from 'zod';
import Card from '../models/Card.js';
import Notification from '../models/Notification.js';
import { HttpError, wrap } from '../utils/http.js';
import { dto } from '../utils/dto.js';
import { isId } from '../utils/mongo.js';
import { computeRank } from '../services/rank.js';
import { deleteCardCascade } from '../services/cascade.js';
import { loadList } from './list.controller.js';

const objectId = z.string().regex(/^[a-f\d]{24}$/i);

export const cardCreateSchema = z.object({
  title: z.string().trim().min(1).max(200),
  description: z.string().max(10000).optional(),
});
export const cardUpdateSchema = z.object({
  title: z.string().trim().min(1).max(200).optional(),
  description: z.string().max(10000).optional(),
  assignees: z.array(objectId).max(20).optional(),
  labels: z.array(z.object({ name: z.string().max(30), color: z.string().max(20) })).max(10).optional(),
  dueDate: z.coerce.date().nullable().optional(),
  archived: z.boolean().optional(),
});
export const cardMoveSchema = z.object({
  listId: objectId,
  afterId: objectId.nullish(),
  beforeId: objectId.nullish(),
  opId: z.string().max(64).optional(),
});

async function loadCard(boardId, cardId) {
  if (!isId(cardId)) throw new HttpError(400, 'Invalid card id');
  const card = await Card.findOne({ _id: cardId, board: boardId });
  if (!card) throw new HttpError(404, 'Card not found');
  return card;
}

export const createCard = wrap(async (req, res) => {
  const list = await loadList(req.board._id, req.params.listId);
  const { rank } = await computeRank(Card, { list: list._id });
  const card = await Card.create({
    ...req.body, board: req.board._id, list: list._id, rank, createdBy: req.user._id,
  });
  res.status(201).json({ card: dto(card) });
});

export const getCard = wrap(async (req, res) => {
  res.json({ card: dto(await loadCard(req.board._id, req.params.cardId)) });
});

export const updateCard = wrap(async (req, res) => {
  const card = await loadCard(req.board._id, req.params.cardId);
  let newlyAssigned = [];
  if (req.body.assignees) {
    const memberIds = new Set(req.workspace.members.map((m) => String(m.user)));
    if (!req.body.assignees.every((id) => memberIds.has(id))) {
      throw new HttpError(400, 'Assignees must be workspace members');
    }
    const before = new Set(card.assignees.map(String));
    newlyAssigned = req.body.assignees.filter((id) => !before.has(id) && id !== String(req.user._id));
  }
  Object.assign(card, req.body);
  await card.save();
  if (newlyAssigned.length) {
    await Notification.insertMany(
      newlyAssigned.map((user) => ({
        user, type: 'assigned',
        refs: { workspace: req.workspace._id, board: req.board._id, card: card._id, actor: req.user._id },
      }))
    );
  }
  res.json({ card: dto(card) });
});

export const moveCard = wrap(async (req, res) => {
  const card = await loadCard(req.board._id, req.params.cardId);
  const { listId, afterId, beforeId, opId } = req.body;
  const toList = await loadList(req.board._id, listId);
  const { rank, rebalanced } = await computeRank(Card, { list: toList._id }, { afterId, beforeId, excludeId: card._id });
  // Targeted $set so a concurrent edit to title/description isn't overwritten
  const updated = await Card.findByIdAndUpdate(card._id, { $set: { list: toList._id, rank } }, { new: true });
  res.json({ card: dto(updated), rebalanced, opId });
});

export const deleteCard = wrap(async (req, res) => {
  const card = await loadCard(req.board._id, req.params.cardId);
  await deleteCardCascade(card._id);
  res.status(204).end();
});
