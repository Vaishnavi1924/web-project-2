import { z } from 'zod';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { HttpError, wrap } from '../utils/http.js';
import { signAccess, signRefresh, verifyRefresh, refreshCookieOpts } from '../utils/tokens.js';

export const registerSchema = z.object({
  name: z.string().trim().min(1).max(80),
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(8).max(128),
});
export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1),
});

const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, avatar: u.avatar });

function issueTokens(res, user) {
  res.cookie('refresh_token', signRefresh(user._id), refreshCookieOpts);
  return { accessToken: signAccess(user._id), user: publicUser(user) };
}

export const register = wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (await User.exists({ email })) throw new HttpError(409, 'Email already registered');
  const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12) });
  res.status(201).json(issueTokens(res, user));
});

export const login = wrap(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+passwordHash');
  const ok = user && (await bcrypt.compare(password, user.passwordHash));
  if (!ok) throw new HttpError(401, 'Invalid email or password');
  res.json(issueTokens(res, user));
});

export const refresh = wrap(async (req, res) => {
  const token = req.cookies?.refresh_token;
  if (!token) throw new HttpError(401, 'No refresh token');
  let payload;
  try {
    payload = verifyRefresh(token);
  } catch {
    throw new HttpError(401, 'Invalid refresh token');
  }
  const user = await User.findById(payload.sub);
  if (!user) throw new HttpError(401, 'User not found');
  res.json(issueTokens(res, user));
});

export const logout = (_req, res) => {
  res.clearCookie('refresh_token', { ...refreshCookieOpts, maxAge: undefined });
  res.status(204).end();
};

export const me = (req, res) => res.json({ user: publicUser(req.user) });
