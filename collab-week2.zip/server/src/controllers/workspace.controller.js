import { z } from 'zod';
import Workspace, { ROLES } from '../models/Workspace.js';
import User from '../models/User.js';
import Notification from '../models/Notification.js';
import { HttpError, wrap } from '../utils/http.js';
import { newInviteToken, hashToken } from '../utils/tokens.js';
import { deleteWorkspaceCascade } from '../services/cascade.js';

export const createSchema = z.object({
  name: z.string().trim().min(1).max(80),
  description: z.string().max(500).optional(),
});
export const updateSchema = createSchema.partial();
export const inviteSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  role: z.enum(ROLES).default('member'),
});
export const acceptSchema = z.object({ token: z.string().length(64) });
export const roleSchema = z.object({ role: z.enum(ROLES) });

const adminCount = (ws) => ws.members.filter((m) => m.role === 'admin').length;

// Strip secrets from what we return to clients (token hashes never leave the server)
const serialize = (ws, role) => ({
  id: ws._id,
  name: ws.name,
  description: ws.description,
  owner: ws.owner,
  members: ws.members,
  role,
  invites:
    role === 'admin'
      ? ws.invites.map((i) => ({ id: i._id, email: i.email, role: i.role, expiresAt: i.expiresAt }))
      : undefined,
});

export const create = wrap(async (req, res) => {
  const ws = await Workspace.create({
    ...req.body,
    owner: req.user._id,
    members: [{ user: req.user._id, role: 'admin' }],
  });
  res.status(201).json({ workspace: serialize(ws, 'admin') });
});

export const listMine = wrap(async (req, res) => {
  const list = await Workspace.find({ 'members.user': req.user._id }).select('-invites').sort('name');
  res.json({
    workspaces: list.map((w) =>
      serialize(w, w.members.find((m) => String(m.user) === String(req.user._id)).role)
    ),
  });
});

export const getOne = wrap(async (req, res) => {
  await req.workspace.populate('members.user', 'name email avatar');
  res.json({ workspace: serialize(req.workspace, req.role) });
});

export const update = wrap(async (req, res) => {
  Object.assign(req.workspace, req.body);
  await req.workspace.save();
  res.json({ workspace: serialize(req.workspace, req.role) });
});

export const remove = wrap(async (req, res) => {
  if (String(req.workspace.owner) !== String(req.user._id)) {
    throw new HttpError(403, 'Only the owner can delete a workspace');
  }
  await deleteWorkspaceCascade(req.workspace._id);
  res.status(204).end();
});

export const invite = wrap(async (req, res) => {
  const { email, role } = req.body;
  const ws = req.workspace;
  const existingUser = await User.findOne({ email });
  if (existingUser && ws.members.some((m) => String(m.user) === String(existingUser._id))) {
    throw new HttpError(409, 'User is already a member');
  }
  // Replace any prior pending invite for the same email
  ws.invites = ws.invites.filter((i) => i.email !== email);
  const token = newInviteToken();
  ws.invites.push({
    email,
    role,
    tokenHash: hashToken(token),
    invitedBy: req.user._id,
    expiresAt: new Date(Date.now() + 7 * 24 * 3600 * 1000),
  });
  await ws.save();

  if (existingUser) {
    await Notification.create({
      user: existingUser._id,
      type: 'invited',
      refs: { workspace: ws._id, actor: req.user._id },
    });
  }
  // TODO: email `${CLIENT_ORIGIN}/invite?token=${token}`.
  // The raw token is returned only outside production so you can test without an email provider.
  const body = { message: 'Invite created' };
  if (process.env.NODE_ENV !== 'production') body.devToken = token;
  res.status(201).json(body);
});

export const revokeInvite = wrap(async (req, res) => {
  req.workspace.invites.pull(req.params.inviteId);
  await req.workspace.save();
  res.status(204).end();
});

export const acceptInvite = wrap(async (req, res) => {
  const tokenHash = hashToken(req.body.token);
  const ws = await Workspace.findOne({ 'invites.tokenHash': tokenHash });
  if (!ws) throw new HttpError(404, 'Invite not found');
  const inv = ws.invites.find((i) => i.tokenHash === tokenHash);
  if (inv.expiresAt < new Date()) throw new HttpError(410, 'Invite expired');
  if (inv.email !== req.user.email) throw new HttpError(403, 'This invite was sent to a different email');

  if (!ws.members.some((m) => String(m.user) === String(req.user._id))) {
    ws.members.push({ user: req.user._id, role: inv.role });
  }
  ws.invites.pull(inv._id);
  await ws.save();
  res.json({ workspace: serialize(ws, inv.role) });
});

export const updateMemberRole = wrap(async (req, res) => {
  const ws = req.workspace;
  const m = ws.members.find((x) => String(x.user) === req.params.userId);
  if (!m) throw new HttpError(404, 'Member not found');
  if (m.role === 'admin' && req.body.role !== 'admin' && adminCount(ws) === 1) {
    throw new HttpError(400, 'Workspace needs at least one admin');
  }
  m.role = req.body.role;
  await ws.save();
  res.json({ members: ws.members });
});

export const removeMember = wrap(async (req, res) => {
  const ws = req.workspace;
  const { userId } = req.params;
  const isSelf = userId === String(req.user._id);
  if (!isSelf && req.role !== 'admin') throw new HttpError(403, 'Insufficient permissions');
  const m = ws.members.find((x) => String(x.user) === userId);
  if (!m) throw new HttpError(404, 'Member not found');
  if (String(ws.owner) === userId) throw new HttpError(400, 'Owner cannot be removed');
  if (m.role === 'admin' && adminCount(ws) === 1) throw new HttpError(400, 'Workspace needs at least one admin');
  ws.members = ws.members.filter((x) => String(x.user) !== userId);
  await ws.save();
  res.status(204).end();
});
