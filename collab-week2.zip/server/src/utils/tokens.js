import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { env } from '../config/env.js';

export const signAccess = (userId) =>
  jwt.sign({ sub: String(userId) }, env.accessSecret, { expiresIn: '15m' });

export const signRefresh = (userId) =>
  jwt.sign({ sub: String(userId) }, env.refreshSecret, { expiresIn: '7d' });

export const verifyAccess = (t) => jwt.verify(t, env.accessSecret);
export const verifyRefresh = (t) => jwt.verify(t, env.refreshSecret);

export const newInviteToken = () => crypto.randomBytes(32).toString('hex');
export const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

export const refreshCookieOpts = {
  httpOnly: true,
  secure: env.isProd,
  sameSite: env.isProd ? 'strict' : 'lax',
  path: '/api/auth',
  maxAge: 7 * 24 * 3600 * 1000,
};
