export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
// Forward async errors to Express error handler
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
