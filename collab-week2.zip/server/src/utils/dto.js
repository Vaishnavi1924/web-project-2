// Mongo doc -> plain object with `id` instead of `_id`/`__v`
export function dto(doc) {
  const o = typeof doc.toObject === 'function' ? doc.toObject() : doc;
  const { _id, __v, ...rest } = o;
  return { id: String(_id), ...rest };
}
