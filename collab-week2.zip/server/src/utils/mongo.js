import mongoose from 'mongoose';

// `sanitizeFilter` is enabled globally, which neutralises any $operator in a filter.
// Operators we build ourselves on the server must be explicitly marked as trusted.
export const t = (op) => mongoose.trusted(op);
export const isId = (v) => typeof v === 'string' && /^[a-f\d]{24}$/i.test(v);
