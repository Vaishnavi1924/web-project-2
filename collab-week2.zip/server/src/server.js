import http from 'node:http';
import { env } from './config/env.js';
import { connectDB } from './config/db.js';
import { createApp } from './app.js';

await connectDB();
const server = http.createServer(createApp()); // Socket.io attaches to this server in Week 3
server.listen(env.port, () => console.log(`API listening on :${env.port}`));
