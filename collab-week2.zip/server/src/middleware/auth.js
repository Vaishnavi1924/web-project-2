import User from '../models/User.js';
import { verifyAccess } from '../utils/tokens.js';
import { HttpError, wrap } from '../utils/http.js';

export const requireAuth = wrap(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new HttpError(401, 'Missing token');
  let payload;
  try {
    payload = verifyAccess(token);
  } catch {
    throw new HttpError(401, 'Invalid or expired token');
  }
  const user = await User.findById(payload.sub);
  if (!user) throw new HttpError(401, 'User no longer exists');
  req.user = user;
  next();
});
