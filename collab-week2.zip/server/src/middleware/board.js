import Board from '../models/Board.js';
import Workspace from '../models/Workspace.js';
import { RANK } from './workspace.js';
import { HttpError, wrap } from '../utils/http.js';
import { isId } from '../utils/mongo.js';

/** Loads :boardId, checks the user's role in the owning workspace. Sets req.board / req.workspace / req.role. */
export const requireBoardRole = (minRole = 'viewer') =>
  wrap(async (req, _res, next) => {
    const { boardId } = req.params;
    if (!isId(boardId)) throw new HttpError(400, 'Invalid board id');
    const board = await Board.findById(boardId);
    if (!board) throw new HttpError(404, 'Board not found');
    const ws = await Workspace.findById(board.workspace).select('members owner');
    const m = ws?.members.find((x) => String(x.user) === String(req.user._id));
    if (!m) throw new HttpError(403, 'Not a member of this workspace');
    if (RANK[m.role] < RANK[minRole]) throw new HttpError(403, 'Insufficient permissions');
    req.board = board;
    req.workspace = ws;
    req.role = m.role;
    next();
  });
