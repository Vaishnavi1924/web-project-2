import mongoose from 'mongoose';
import Workspace from '../models/Workspace.js';
import { HttpError, wrap } from '../utils/http.js';

export const RANK = { viewer: 0, member: 1, admin: 2 };

/** Loads :workspaceId, checks membership and minimum role. Sets req.workspace / req.role. */
export const requireWorkspaceRole = (minRole = 'viewer') =>
  wrap(async (req, _res, next) => {
    const { workspaceId } = req.params;
    if (!mongoose.isValidObjectId(workspaceId)) throw new HttpError(400, 'Invalid workspace id');
    const ws = await Workspace.findById(workspaceId);
    if (!ws) throw new HttpError(404, 'Workspace not found');
    const m = ws.members.find((x) => String(x.user) === String(req.user._id));
    if (!m) throw new HttpError(403, 'Not a member of this workspace');
    if (RANK[m.role] < RANK[minRole]) throw new HttpError(403, 'Insufficient permissions');
    req.workspace = ws;
    req.role = m.role;
    next();
  });
