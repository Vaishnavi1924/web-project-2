import { generateKeyBetween, generateNKeysBetween } from 'fractional-indexing';
import { t } from '../utils/mongo.js';
import { HttpError } from '../utils/http.js';

async function rankOf(Model, scope, id, excludeId) {
  if (!id || String(id) === String(excludeId)) return null;
  const d = await Model.findOne({ ...scope, _id: id }).select('rank').lean();
  return d?.rank ?? null;
}

async function neighbour(Model, scope, rank, dir, excludeId) {
  const q = { ...scope, rank: t(dir > 0 ? { $gt: rank } : { $lt: rank }) };
  if (excludeId) q._id = t({ $ne: excludeId });
  const d = await Model.findOne(q).sort({ rank: dir > 0 ? 1 : -1 }).select('rank').lean();
  return d?.rank ?? null;
}

async function lastRank(Model, scope, excludeId) {
  const q = { ...scope };
  if (excludeId) q._id = t({ $ne: excludeId });
  const d = await Model.findOne(q).sort({ rank: -1 }).select('rank').lean();
  return d?.rank ?? null;
}

/** Re-spaces every rank in `scope`. Only used when two neighbours have collided. */
export async function rebalance(Model, scope) {
  const docs = await Model.find(scope).sort({ rank: 1, _id: 1 }).select('_id').lean();
  const keys = generateNKeysBetween(null, null, docs.length);
  if (docs.length) {
    await Model.bulkWrite(
      docs.map((d, i) => ({ updateOne: { filter: { _id: d._id }, update: { $set: { rank: keys[i] } } } }))
    );
  }
  return docs.map((d, i) => ({ id: String(d._id), rank: keys[i] }));
}

/**
 * Compute a rank that places an item between `afterId` (above) and `beforeId` (below).
 * Robust to stale clients: missing neighbours are replaced by the real adjacent item in the DB,
 * and no neighbours at all means "append to the end".
 * Returns { rank, rebalanced? } — `rebalanced` lists new ranks for the whole scope if a rebalance occurred.
 */
export async function computeRank(Model, scope, { afterId, beforeId, excludeId } = {}) {
  let rebalanced;
  for (let attempt = 0; attempt < 2; attempt++) {
    let a = await rankOf(Model, scope, afterId, excludeId);
    let b = await rankOf(Model, scope, beforeId, excludeId);
    if (a === null && b === null) a = await lastRank(Model, scope, excludeId);
    else if (b === null) b = await neighbour(Model, scope, a, 1, excludeId);
    else if (a === null) a = await neighbour(Model, scope, b, -1, excludeId);
    try {
      return { rank: generateKeyBetween(a, b), rebalanced };
    } catch {
      rebalanced = await rebalance(Model, scope); // a >= b: collision, respace and retry
    }
  }
  throw new HttpError(409, 'Could not compute position, please retry');
}
