import Board from '../models/Board.js';
import List from '../models/List.js';
import Card from '../models/Card.js';
import Comment from '../models/Comment.js';
import Workspace from '../models/Workspace.js';
import { t } from '../utils/mongo.js';

const ids = (docs) => docs.map((d) => d._id);

export async function deleteCardsWhere(filter) {
  const cards = await Card.find(filter).select('_id').lean();
  if (!cards.length) return;
  await Comment.deleteMany({ card: t({ $in: ids(cards) }) });
  await Card.deleteMany({ _id: t({ $in: ids(cards) }) });
}

export const deleteCardCascade = (cardId) => deleteCardsWhere({ _id: cardId });

export async function deleteListCascade(listId) {
  await deleteCardsWhere({ list: listId });
  await List.deleteOne({ _id: listId });
}

export async function deleteBoardsCascade(boardIds) {
  if (!boardIds.length) return;
  await deleteCardsWhere({ board: t({ $in: boardIds }) });
  await List.deleteMany({ board: t({ $in: boardIds }) });
  await Board.deleteMany({ _id: t({ $in: boardIds }) });
}

export async function deleteWorkspaceCascade(workspaceId) {
  const boards = await Board.find({ workspace: workspaceId }).select('_id').lean();
  await deleteBoardsCascade(ids(boards));
  await Workspace.deleteOne({ _id: workspaceId });
}
