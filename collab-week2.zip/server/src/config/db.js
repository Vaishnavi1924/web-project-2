import mongoose from 'mongoose';
import { env } from './env.js';

export async function connectDB() {
  mongoose.set('sanitizeFilter', true); // blocks NoSQL operator injection in filters
  await mongoose.connect(env.mongoUri);
  console.log('MongoDB connected');
}
