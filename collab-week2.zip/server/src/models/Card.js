import mongoose from 'mongoose';

const cardSchema = new mongoose.Schema(
  {
    board: { type: mongoose.Schema.Types.ObjectId, ref: 'Board', required: true },
    list: { type: mongoose.Schema.Types.ObjectId, ref: 'List', required: true },
    title: { type: String, required: true, trim: true, maxlength: 200 },
    description: { type: String, default: '' },
    rank: { type: String, required: true }, // fractional-index string
    assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    labels: [{ name: String, color: String }],
    dueDate: Date,
    archived: { type: Boolean, default: false },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

cardSchema.index({ board: 1, list: 1, rank: 1 });
cardSchema.index({ title: 'text', description: 'text' });

export default mongoose.model('Card', cardSchema);
