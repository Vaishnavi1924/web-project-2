import mongoose from 'mongoose';

export const ROLES = ['admin', 'member', 'viewer'];

const memberSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    role: { type: String, enum: ROLES, default: 'member' },
  },
  { _id: false }
);

const inviteSchema = new mongoose.Schema({
  email: { type: String, required: true, lowercase: true, trim: true },
  role: { type: String, enum: ROLES, default: 'member' },
  tokenHash: { type: String, required: true }, // only the hash is stored
  invitedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  expiresAt: { type: Date, required: true },
});

const workspaceSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    description: { type: String, default: '', maxlength: 500 },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    members: [memberSchema],
    invites: [inviteSchema],
  },
  { timestamps: true }
);

workspaceSchema.index({ 'members.user': 1 });
workspaceSchema.index({ 'invites.tokenHash': 1 });

export default mongoose.model('Workspace', workspaceSchema);
