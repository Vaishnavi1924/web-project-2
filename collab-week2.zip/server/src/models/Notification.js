import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: { type: String, enum: ['assigned', 'mentioned', 'commented', 'invited', 'due_soon'], required: true },
    refs: {
      workspace: mongoose.Schema.Types.ObjectId,
      board: mongoose.Schema.Types.ObjectId,
      card: mongoose.Schema.Types.ObjectId,
      actor: mongoose.Schema.Types.ObjectId,
    },
    readAt: Date,
  },
  { timestamps: true }
);

notificationSchema.index({ user: 1, readAt: 1, createdAt: -1 });

export default mongoose.model('Notification', notificationSchema);
