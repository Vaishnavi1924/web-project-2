import mongoose from 'mongoose';

const listSchema = new mongoose.Schema(
  {
    board: { type: mongoose.Schema.Types.ObjectId, ref: 'Board', required: true },
    title: { type: String, required: true, trim: true, maxlength: 120 },
    rank: { type: String, required: true }, // fractional-index string
    archived: { type: Boolean, default: false },
  },
  { timestamps: true }
);

listSchema.index({ board: 1, rank: 1 });

export default mongoose.model('List', listSchema);
