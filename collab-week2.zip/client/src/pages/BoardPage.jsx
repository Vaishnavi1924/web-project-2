import { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useBoard } from '../store/boardStore.js';
import Board from '../components/Board.jsx';
import CardModal from '../components/CardModal.jsx';

export default function BoardPage() {
  const { boardId } = useParams();
  const title = useBoard((s) => s.board?.title);
  const loading = useBoard((s) => s.loading);
  const error = useBoard((s) => s.error);
  const toast = useBoard((s) => s.toast);

  useEffect(() => {
    useBoard.getState().load(boardId);
    return () => useBoard.getState().reset();
  }, [boardId]);

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-4 bg-blue-700 px-4 py-2.5 text-white">
        <Link to="/" className="text-sm text-blue-100 hover:text-white">← Boards</Link>
        <h1 className="font-semibold">{title}</h1>
      </header>
      <div className="min-h-0 flex-1">
        {loading && <p className="p-6 text-slate-500">Loading…</p>}
        {error && <p className="p-6 text-red-600">{error}</p>}
        {!loading && !error && title && <Board />}
      </div>
      <CardModal />
      {toast && <div className="fixed bottom-4 left-1/2 -translate-x-1/2 rounded bg-slate-900 px-4 py-2 text-sm text-white shadow-lg">{toast}</div>}
    </div>
  );
}
