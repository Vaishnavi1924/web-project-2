import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../store/authStore.js';

export default function Login() {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const nav = useNavigate();
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const body = mode === 'login' ? { email: form.email, password: form.password } : form;
      useAuth.getState().setSession(await api(`/auth/${mode}`, { method: 'POST', body }));
      nav('/', { replace: true });
    } catch (err) {
      setError(err.message);
    }
  };

  const input = 'w-full rounded border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500';
  return (
    <div className="grid h-full place-items-center">
      <form onSubmit={submit} className="w-80 space-y-3 rounded-lg bg-white p-6 shadow">
        <h1 className="text-xl font-semibold">{mode === 'login' ? 'Sign in' : 'Create account'}</h1>
        {mode === 'register' && <input className={input} placeholder="Name" value={form.name} onChange={set('name')} required />}
        <input className={input} type="email" placeholder="Email" value={form.email} onChange={set('email')} required />
        <input className={input} type="password" placeholder="Password (min 8)" value={form.password} onChange={set('password')} required minLength={mode === 'register' ? 8 : 1} />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button className="w-full rounded bg-blue-600 py-2 text-sm font-medium text-white hover:bg-blue-700">
          {mode === 'login' ? 'Sign in' : 'Sign up'}
        </button>
        <button type="button" className="w-full text-sm text-slate-500 hover:text-slate-800"
          onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? 'Need an account? Register' : 'Have an account? Sign in'}
        </button>
      </form>
    </div>
  );
}
