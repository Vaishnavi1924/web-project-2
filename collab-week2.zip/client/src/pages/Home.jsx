import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../store/authStore.js';
import AddItem from '../components/AddItem.jsx';

// Minimal stand-in for the Week 1 sidebar: pick a workspace, pick or create a board.
export default function Home() {
  const user = useAuth((s) => s.user);
  const [workspaces, setWorkspaces] = useState([]);
  const [wsId, setWsId] = useState(null);
  const [boards, setBoards] = useState([]);

  useEffect(() => {
    api('/workspaces').then((d) => {
      setWorkspaces(d.workspaces);
      setWsId((cur) => cur ?? d.workspaces[0]?.id ?? null);
    });
  }, []);
  useEffect(() => {
    if (wsId) api(`/workspaces/${wsId}/boards`).then((d) => setBoards(d.boards));
  }, [wsId]);

  const createWs = async (name) => {
    const { workspace } = await api('/workspaces', { method: 'POST', body: { name } });
    setWorkspaces((w) => [...w, workspace]);
    setWsId(workspace.id);
  };
  const createBoard = async (title) => {
    const { board } = await api(`/workspaces/${wsId}/boards`, { method: 'POST', body: { title } });
    setBoards((b) => [board, ...b]);
  };
  const logout = async () => {
    await api('/auth/logout', { method: 'POST' });
    useAuth.getState().clear();
  };

  return (
    <div className="flex h-full">
      <aside className="w-60 shrink-0 bg-slate-900 p-3 text-slate-200">
        <div className="mb-4 text-sm text-slate-400">{user?.name}</div>
        <div className="mb-1 text-xs font-semibold uppercase text-slate-500">Workspaces</div>
        {workspaces.map((w) => (
          <button key={w.id} onClick={() => setWsId(w.id)}
            className={`block w-full truncate rounded px-2 py-1.5 text-left text-sm ${w.id === wsId ? 'bg-slate-700' : 'hover:bg-slate-800'}`}>
            {w.name}
          </button>
        ))}
        <AddItem label="New workspace" onAdd={createWs} className="mt-1 text-slate-300" />
        <button onClick={logout} className="mt-6 text-sm text-slate-400 hover:text-white">Sign out</button>
      </aside>
      <main className="flex-1 overflow-y-auto p-6">
        {!wsId ? <p className="text-slate-500">Create a workspace to get started.</p> : (
          <>
            <h2 className="mb-4 text-lg font-semibold">Boards</h2>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {boards.map((b) => (
                <Link key={b.id} to={`/b/${b.id}`} className="rounded-lg bg-blue-600 p-4 font-medium text-white hover:bg-blue-700">{b.title}</Link>
              ))}
              <div className="rounded-lg bg-slate-200 p-2"><AddItem label="Create board" onAdd={createBoard} /></div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
