import { memo, useState } from 'react';
import { Draggable, Droppable } from '@hello-pangea/dnd';
import { useBoard } from '../store/boardStore.js';
import Card from './Card.jsx';
import AddItem from './AddItem.jsx';

function List({ id, index }) {
  const list = useBoard((s) => s.lists[id]);
  const cardIds = useBoard((s) => s.cardsByList[id]);
  const { renameList, deleteList, addCard } = useBoard.getState();
  const [editing, setEditing] = useState(false);
  if (!list) return null;

  const commitTitle = (e) => {
    setEditing(false);
    const v = e.target.value.trim();
    if (v) renameList(id, v);
  };

  return (
    <Draggable draggableId={id} index={index}>
      {(p, snap) => (
        <div ref={p.innerRef} {...p.draggableProps}
          className={`w-72 shrink-0 rounded-lg bg-slate-200 ${snap.isDragging ? 'shadow-xl' : ''} ${list.pending ? 'opacity-60' : ''}`}>
          <div {...p.dragHandleProps} className="flex items-center justify-between px-3 pt-2.5 pb-1">
            {editing ? (
              <input autoFocus defaultValue={list.title} onBlur={commitTitle}
                onKeyDown={(e) => (e.key === 'Enter' ? e.target.blur() : e.key === 'Escape' && setEditing(false))}
                className="w-full rounded border border-blue-500 px-1 text-sm font-semibold outline-none" />
            ) : (
              <h3 onDoubleClick={() => setEditing(true)} className="flex-1 truncate text-sm font-semibold" title="Double-click to rename">
                {list.title} <span className="ml-1 font-normal text-slate-500">{cardIds?.length ?? 0}</span>
              </h3>
            )}
            <button onClick={() => confirm(`Delete "${list.title}" and all its cards?`) && deleteList(id)}
              className="ml-2 rounded px-1 text-slate-500 hover:bg-slate-300 hover:text-red-600" aria-label="Delete list">✕</button>
          </div>

          <Droppable droppableId={id} type="CARD">
            {(dp, ds) => (
              <div ref={dp.innerRef} {...dp.droppableProps}
                className={`mx-2 min-h-10 rounded p-1 transition-colors ${ds.isDraggingOver ? 'bg-blue-100/60' : ''}`}>
                {(cardIds ?? []).map((cid, i) => <Card key={cid} id={cid} index={i} />)}
                {dp.placeholder}
              </div>
            )}
          </Droppable>

          <div className="p-2 pt-0"><AddItem label="Add a card" onAdd={(t) => addCard(id, t)} /></div>
        </div>
      )}
    </Draggable>
  );
}

export default memo(List);
