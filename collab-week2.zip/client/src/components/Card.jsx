import { memo } from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { useBoard } from '../store/boardStore.js';

const initials = (name = '?') => name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();

function Card({ id, index }) {
  const card = useBoard((s) => s.cards[id]);
  const members = useBoard((s) => s.members);
  const openCard = useBoard((s) => s.openCard);
  if (!card) return null;
  const overdue = card.dueDate && new Date(card.dueDate) < new Date();

  return (
    <Draggable draggableId={id} index={index}>
      {(p, snap) => (
        <div ref={p.innerRef} {...p.draggableProps} {...p.dragHandleProps}
          onClick={() => openCard(id)}
          className={`mb-2 cursor-pointer rounded-md border bg-white p-2.5 text-sm shadow-sm hover:border-blue-400
            ${snap.isDragging ? 'rotate-2 border-blue-500 shadow-lg' : 'border-slate-200'} ${card.pending ? 'opacity-60' : ''}`}>
          {card.labels?.length > 0 && (
            <div className="mb-1.5 flex flex-wrap gap-1">
              {card.labels.map((l, i) => (
                <span key={i} className="rounded px-1.5 text-[10px] font-medium text-white" style={{ background: l.color || '#64748b' }}>{l.name}</span>
              ))}
            </div>
          )}
          <div className="break-words">{card.title}</div>
          {(card.dueDate || card.assignees?.length > 0) && (
            <div className="mt-2 flex items-center justify-between">
              {card.dueDate
                ? <span className={`rounded px-1.5 text-xs ${overdue ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}`}>
                    {new Date(card.dueDate).toLocaleDateString()}
                  </span>
                : <span />}
              <div className="flex -space-x-1">
                {card.assignees.map((uid) => (
                  <span key={uid} title={members.find((m) => m.id === uid)?.name}
                    className="grid h-6 w-6 place-items-center rounded-full bg-indigo-500 text-[10px] font-semibold text-white ring-2 ring-white">
                    {initials(members.find((m) => m.id === uid)?.name)}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </Draggable>
  );
}

export default memo(Card);
