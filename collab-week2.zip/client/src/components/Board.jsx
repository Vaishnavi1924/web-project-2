import { DragDropContext, Droppable } from '@hello-pangea/dnd';
import { useBoard } from '../store/boardStore.js';
import List from './List.jsx';
import AddItem from './AddItem.jsx';

export default function Board() {
  const listOrder = useBoard((s) => s.listOrder);
  const canEdit = useBoard((s) => s.role !== 'viewer');
  const { moveList, moveCard, addList } = useBoard.getState();

  const onDragEnd = ({ destination, source, draggableId, type }) => {
    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;
    if (type === 'LIST') moveList(draggableId, destination.index);
    else moveCard(draggableId, destination.droppableId, destination.index);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <Droppable droppableId="board" type="LIST" direction="horizontal" isDropDisabled={!canEdit}>
        {(p) => (
          <div ref={p.innerRef} {...p.droppableProps} className="flex h-full items-start gap-3 overflow-x-auto p-4">
            {listOrder.map((id, i) => <List key={id} id={id} index={i} />)}
            {p.placeholder}
            {canEdit && (
              <div className="w-72 shrink-0 rounded-lg bg-slate-200/60 p-2">
                <AddItem label="Add another list" onAdd={addList} />
              </div>
            )}
          </div>
        )}
      </Droppable>
    </DragDropContext>
  );
}
