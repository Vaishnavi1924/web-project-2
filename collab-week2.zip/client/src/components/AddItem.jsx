import { useState } from 'react';

export default function AddItem({ label, onAdd, className = '' }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');

  const submit = (e) => {
    e.preventDefault();
    const v = text.trim();
    if (v) onAdd(v);
    setText('');
  };

  if (!open) {
    return (
      <button onClick={() => setOpen(true)}
        className={`w-full rounded-md px-2 py-1.5 text-left text-sm text-slate-600 hover:bg-slate-300/50 ${className}`}>
        + {label}
      </button>
    );
  }
  return (
    <form onSubmit={submit} className={className}>
      <input autoFocus value={text} onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
        placeholder={label} maxLength={200}
        className="w-full rounded-md border border-slate-300 bg-white px-2 py-1.5 text-sm outline-none focus:border-blue-500" />
      <div className="mt-1.5 flex gap-2">
        <button className="rounded-md bg-blue-600 px-3 py-1 text-sm text-white hover:bg-blue-700">Add</button>
        <button type="button" onClick={() => setOpen(false)} className="text-sm text-slate-500 hover:text-slate-800">Cancel</button>
      </div>
    </form>
  );
}
