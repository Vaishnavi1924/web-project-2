import { useEffect } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './store/authStore.js';
import { refreshSession } from './api/client.js';
import Login from './pages/Login.jsx';
import Home from './pages/Home.jsx';
import BoardPage from './pages/BoardPage.jsx';

function Guard({ children }) {
  const { token, ready } = useAuth();
  if (!ready) return <div className="grid h-full place-items-center text-slate-500">Loading…</div>;
  return token ? children : <Navigate to="/login" replace />;
}

export default function App() {
  useEffect(() => {
    refreshSession().finally(() => useAuth.getState().setReady()); // restore session from the cookie
  }, []);

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Guard><Home /></Guard>} />
      <Route path="/b/:boardId" element={<Guard><BoardPage /></Guard>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
