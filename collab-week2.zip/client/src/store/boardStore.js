import { create } from 'zustand';
import { generateKeyBetween } from 'fractional-indexing';
import { api } from '../api/client.js';

/*
 * Normalised board state + optimistic updates.
 *
 * Every mutation:
 *   1. applies locally right away (UI never waits on the network),
 *   2. is queued so requests hit the server strictly in the order the user made them,
 *   3. on failure, reverts. If other ops are still queued behind it, a revert snapshot would clobber
 *      them, so we mark the board for a silent re-fetch once the queue drains instead.
 *
 * Temp ids (tmp_n) stand in for entities the server hasn't created yet; `real()` resolves them
 * lazily inside request closures, which is safe because the queue is sequential.
 */

let seq = 0;
const newTmp = () => `tmp_${++seq}`;
const idMap = new Map(); // tmp id -> real id
const real = (id) => (id ? idMap.get(id) ?? id : id);

let pending = 0;
let chain = Promise.resolve();
let needsResync = false;

const slice = (s) => ({ lists: s.lists, listOrder: s.listOrder, cards: s.cards, cardsByList: s.cardsByList });
const safeRank = (a, b, fallback) => {
  try {
    return generateKeyBetween(a, b);
  } catch {
    return fallback; // equal neighbour ranks: keep old rank, the server will rebalance
  }
};

function build(data) {
  const lists = {};
  const cards = {};
  const cardsByList = {};
  data.lists.forEach((l) => {
    lists[l.id] = l;
    cardsByList[l.id] = [];
  });
  data.cards.forEach((c) => {
    cards[c.id] = c;
    cardsByList[c.list]?.push(c.id); // snapshot is already rank-sorted
  });
  return {
    board: data.board, members: data.members, role: data.role,
    lists, listOrder: data.lists.map((l) => l.id), cards, cardsByList,
  };
}

const empty = {
  board: null, members: [], role: 'viewer', lists: {}, listOrder: [], cards: {}, cardsByList: {},
  loading: false, error: null, toast: null, openCardId: null,
};

export const useBoard = create((set, get) => {
  const boardPath = () => `/boards/${get().board.id}`;

  function run(apply, request, onSuccess) {
    const snap = slice(get());
    set(apply(get()));
    pending++;
    chain = chain.then(async () => {
      try {
        const res = await request(); // NB: not `onSuccess?.(await request())` — that skips the call when onSuccess is undefined
        onSuccess?.(res);
      } catch (e) {
        get().notify(e.message || 'Change failed and was reverted');
        if (pending > 1) needsResync = true;
        else set(snap);
      } finally {
        pending--;
        if (pending === 0 && needsResync) {
          needsResync = false;
          await get().load(get().board.id, { silent: true }).catch(() => {});
        }
      }
    });
    return chain;
  }

  // Apply only server-authoritative ranks (don't overwrite local list/ordering from later optimistic ops)
  const applyRanks = (res) =>
    set((s) => {
      const cards = { ...s.cards };
      const lists = { ...s.lists };
      const patch = (store, id, rank) => store[id] && (store[id] = { ...store[id], rank });
      const item = res.card ?? res.list;
      const target = res.card ? cards : lists;
      patch(target, item.id, item.rank);
      res.rebalanced?.forEach(({ id, rank }) => patch(res.card ? cards : lists, id, rank));
      return { cards, lists };
    });

  return {
    ...empty,

    notify: (msg) => {
      set({ toast: msg });
      setTimeout(() => get().toast === msg && set({ toast: null }), 4000);
    },
    openCard: (id) => set({ openCardId: id }),
    reset: () => {
      idMap.clear();
      pending = 0;
      needsResync = false;
      chain = Promise.resolve();
      set(empty);
    },

    async load(boardId, { silent = false } = {}) {
      if (!silent) set({ loading: true, error: null });
      try {
        set({ ...build(await api(`/boards/${boardId}`)), loading: false });
      } catch (e) {
        set({ error: e.message, loading: false });
        if (silent) throw e;
      }
    },

    // ---------- lists ----------
    addList(title) {
      const id = newTmp();
      const s = get();
      const last = s.lists[s.listOrder.at(-1)]?.rank ?? null;
      const list = { id, title, rank: safeRank(last, null, 'a0'), board: s.board.id, pending: true };
      return run(
        (st) => ({
          lists: { ...st.lists, [id]: list },
          listOrder: [...st.listOrder, id],
          cardsByList: { ...st.cardsByList, [id]: [] },
        }),
        () => api(`${boardPath()}/lists`, { method: 'POST', body: { title } }),
        ({ list: saved }) => {
          idMap.set(id, saved.id);
          set((st) => {
            const { [id]: _l, ...lists } = st.lists;
            const { [id]: cardIds = [], ...cardsByList } = st.cardsByList;
            const cards = { ...st.cards };
            cardIds.forEach((cid) => (cards[cid] = { ...cards[cid], list: saved.id }));
            return {
              lists: { ...lists, [saved.id]: saved },
              listOrder: st.listOrder.map((x) => (x === id ? saved.id : x)),
              cardsByList: { ...cardsByList, [saved.id]: cardIds },
              cards,
            };
          });
        }
      );
    },

    renameList(id, title) {
      const prev = get().lists[id];
      if (!prev || prev.title === title) return;
      return run(
        (s) => ({ lists: { ...s.lists, [id]: { ...s.lists[id], title } } }),
        () => api(`${boardPath()}/lists/${real(id)}`, { method: 'PATCH', body: { title } })
      );
    },

    deleteList(id) {
      return run(
        (s) => {
          const { [id]: _l, ...lists } = s.lists;
          const { [id]: cardIds = [], ...cardsByList } = s.cardsByList;
          const cards = { ...s.cards };
          cardIds.forEach((c) => delete cards[c]);
          return { lists, cardsByList, cards, listOrder: s.listOrder.filter((x) => x !== id) };
        },
        () => api(`${boardPath()}/lists/${real(id)}`, { method: 'DELETE' })
      );
    },

    moveList(listId, toIndex) {
      const s = get();
      const order = s.listOrder.filter((x) => x !== listId);
      order.splice(toIndex, 0, listId);
      const afterId = order[toIndex - 1] ?? null;
      const beforeId = order[toIndex + 1] ?? null;
      const rank = safeRank(s.lists[afterId]?.rank ?? null, s.lists[beforeId]?.rank ?? null, s.lists[listId].rank);
      return run(
        (st) => ({ listOrder: order, lists: { ...st.lists, [listId]: { ...st.lists[listId], rank } } }),
        () =>
          api(`${boardPath()}/lists/${real(listId)}/move`, {
            method: 'POST',
            body: { afterId: real(afterId), beforeId: real(beforeId) },
          }),
        (res) => applyRanks({ list: res.list, rebalanced: res.rebalanced })
      );
    },

    // ---------- cards ----------
    addCard(listId, title) {
      const id = newTmp();
      const s = get();
      const ids = s.cardsByList[listId] ?? [];
      const last = s.cards[ids.at(-1)]?.rank ?? null;
      const card = {
        id, title, description: '', list: listId, board: s.board.id,
        rank: safeRank(last, null, 'a0'), assignees: [], labels: [], pending: true,
      };
      return run(
        (st) => ({
          cards: { ...st.cards, [id]: card },
          cardsByList: { ...st.cardsByList, [listId]: [...(st.cardsByList[listId] ?? []), id] },
        }),
        () => api(`${boardPath()}/lists/${real(listId)}/cards`, { method: 'POST', body: { title } }),
        ({ card: saved }) => {
          idMap.set(id, saved.id);
          set((st) => {
            const { [id]: local, ...cards } = st.cards;
            const cardsByList = {};
            for (const [lid, arr] of Object.entries(st.cardsByList)) {
              cardsByList[lid] = arr.map((x) => (x === id ? saved.id : x));
            }
            // keep the card's *current* local list (user may have dragged it meanwhile)
            return { cards: { ...cards, [saved.id]: { ...saved, list: local?.list ?? saved.list } }, cardsByList,
              openCardId: st.openCardId === id ? saved.id : st.openCardId };
          });
        }
      );
    },

    updateCard(id, patch) {
      return run(
        (s) => ({ cards: { ...s.cards, [id]: { ...s.cards[id], ...patch } } }),
        () => api(`${boardPath()}/cards/${real(id)}`, { method: 'PATCH', body: patch })
      );
    },

    deleteCard(id) {
      return run(
        (s) => {
          const { [id]: card, ...cards } = s.cards;
          return {
            cards,
            cardsByList: { ...s.cardsByList, [card.list]: s.cardsByList[card.list].filter((x) => x !== id) },
            openCardId: s.openCardId === id ? null : s.openCardId,
          };
        },
        () => api(`${boardPath()}/cards/${real(id)}`, { method: 'DELETE' })
      );
    },

    moveCard(cardId, toListId, toIndex) {
      const s = get();
      const card = s.cards[cardId];
      if (!card) return;
      const fromListId = card.list;
      const dest = s.cardsByList[toListId].filter((x) => x !== cardId);
      dest.splice(toIndex, 0, cardId);
      const afterId = dest[toIndex - 1] ?? null;
      const beforeId = dest[toIndex + 1] ?? null;
      const rank = safeRank(s.cards[afterId]?.rank ?? null, s.cards[beforeId]?.rank ?? null, card.rank);
      return run(
        (st) => ({
          cards: { ...st.cards, [cardId]: { ...st.cards[cardId], list: toListId, rank } },
          cardsByList: {
            ...st.cardsByList,
            [fromListId]: st.cardsByList[fromListId].filter((x) => x !== cardId),
            [toListId]: dest, // when from === to, this (later) key wins, which is what we want
          },
        }),
        () =>
          api(`${boardPath()}/cards/${real(cardId)}/move`, {
            method: 'POST',
            body: { listId: real(toListId), afterId: real(afterId), beforeId: real(beforeId) },
          }),
        (res) => applyRanks({ card: res.card, rebalanced: res.rebalanced })
      );
    },
  };
});
