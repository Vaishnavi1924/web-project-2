import { create } from 'zustand';

// Access token lives in memory only; the refresh token is an httpOnly cookie.
export const useAuth = create((set) => ({
  token: null,
  user: null,
  ready: false,
  setSession: ({ accessToken, user }) => set({ token: accessToken, user }),
  clear: () => set({ token: null, user: null }),
  setReady: () => set({ ready: true }),
}));
