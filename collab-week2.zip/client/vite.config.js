import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    // Same-origin in dev so the httpOnly refresh cookie works. Week 3: add '/socket.io' with ws: true.
    proxy: { '/api': 'http://localhost:4000' },
  },
});
