# Collab Workspace — Weeks 1 + 2

    server/   Express + Mongoose API   (Week 1: auth, workspaces, invites;  Week 2: boards, lists, cards, move)
    client/   React + Zustand + Tailwind + @hello-pangea/dnd

## Run
    # terminal 1 (Node 20.6+, MongoDB running)
    cd server && npm install && cp .env.example .env && npm run dev
    # terminal 2
    cd client && npm install && npm run dev      # http://localhost:5173  (proxies /api -> :4000)

## Week 2 endpoints (all under /api/boards, JWT required)
| Method | Path | Role |
|---|---|---|
| GET/POST | /workspaces/:id/boards | viewer / member (new boards get To do / In progress / Done) |
| GET | /boards/:boardId | viewer — full snapshot {board, lists, cards, members, role} |
| PATCH / DELETE | /boards/:boardId | member / admin (delete cascades) |
| POST | /boards/:boardId/lists | member |
| PATCH / DELETE | /boards/:boardId/lists/:listId | member |
| POST | /boards/:boardId/lists/:listId/move  {afterId, beforeId} | member |
| POST | /boards/:boardId/lists/:listId/cards  {title} | member |
| GET / PATCH / DELETE | /boards/:boardId/cards/:cardId | viewer / member / member |
| POST | /boards/:boardId/cards/:cardId/move  {listId, afterId, beforeId} | member |

Move = send the ids of the items now above/below the dropped item. The server derives the rank
(fractional-indexing), tolerates stale neighbours, and rebalances on collision.
