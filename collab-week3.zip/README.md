# Collab Workspace — Weeks 1–3

    server/   Express + Mongoose + Socket.io API
    client/   React + Zustand + Tailwind + @hello-pangea/dnd + socket.io-client

## Run
    # terminal 1 (Node 20.6+, MongoDB running)
    cd server && npm install && cp .env.example .env && npm run dev
    # terminal 2
    cd client && npm install && npm run dev      # http://localhost:5173 (proxies /api and /socket.io -> :4000)

## Tests (no database or browser needed)
    cd server && node test/sockets.test.mjs      # real socket.io clients vs the real socket server
    cd client && node test/store.test.mjs        # optimistic ops, remote events, conflicts, typing, comments

## Real-time architecture
* **Writes go through REST** (one validation + permission path). After a successful write the controller calls
  `emitToBoard(req, event, payload)`, which broadcasts to room `board:<id>` **except** the socket named in the
  `X-Socket-Id` header, so the author never gets an echo of their own change.
* **Handshake auth:** JWT in `socket.handshake.auth.token`, verified in `io.use` before the connection exists.
  The client passes `auth` as a function so every reconnect carries a fresh token; on `Unauthorized` it
  refreshes the session and reconnects once.
* **`board:join`** re-checks workspace membership every time (same `getBoardAccess` as REST).
  Removing a member calls `kickUser`, dropping their sockets; their re-join is then refused.
* **Presence:** `board:join/leave/disconnect` -> `presence:update` (one entry per user, however many tabs).
* **Typing:** `typing:start/stop` (client throttled to 2s, server TTL 5s, client expiry 6s, cleared on disconnect).
* **Reconnect:** Socket.io doesn't replay missed events, so on every (re)connect the client rejoins the room and
  re-fetches the board snapshot (and the open comment thread).
* **Conflicts:** a remote event touching an entity with an in-flight local op is dropped and a single
  authoritative re-fetch runs when the local queue drains.

## Events (server -> room)
card:created|updated|moved|deleted, list:created|updated|moved|deleted, board:updated|deleted,
comment:added|deleted, presence:update, typing:update.   (server -> user room: notification:new)

## New endpoints
GET/POST /api/boards/:boardId/cards/:cardId/comments   (viewer / member)
DELETE   /api/boards/:boardId/comments/:commentId      (author or admin)
