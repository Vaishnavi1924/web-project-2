// Run: node test/store.test.mjs   (mocks fetch; no browser/server needed)
const calls = [];
let failNext = 0, delay = 0, nextId = 100, snapshot;
globalThis.fetch = async (url, opts = {}) => {
  const body = opts.body ? JSON.parse(opts.body) : undefined;
  const method = opts.method || 'GET';
  calls.push({ method, url, body });
  if (delay) await new Promise((r) => setTimeout(r, delay));
  const json = (status, data) => ({ ok: status < 400, status, json: async () => data });
  if (method === 'GET' && url === '/api/boards/b1') return json(200, snapshot());
  if (failNext > 0) { failNext--; return json(500, { error: 'boom' }); }
  if (url.endsWith('/comments') && method === 'POST') return json(201, { comment: { id: 'cm' + nextId++, card: 'c1', body: body.body, createdAt: new Date().toISOString(), author: { id: 'me', name: 'Me' } } });
  if (url.endsWith('/cards') && method === 'POST') return json(201, { card: { id: 'real' + nextId++, ...body, description: '', list: url.split('/').at(-2), rank: 'a9', assignees: [], labels: [] } });
  if (url.endsWith('/lists') && method === 'POST') return json(201, { list: { id: 'reallist' + nextId++, ...body, rank: 'a9' } });
  if (url.endsWith('/move')) return json(200, { card: { id: url.split('/').at(-2), rank: 'srv-rank', list: body.listId }, list: { id: url.split('/').at(-2), rank: 'srv-rank' } });
  return json(200, {});
};
const { useBoard } = await import('../src/store/boardStore.js');
const { useComments } = await import('../src/store/commentStore.js');
const S = () => useBoard.getState();
const snap0 = () => ({
  board: { id: 'b1', title: 'B' }, members: [], role: 'member',
  lists: [{ id: 'L1', title: 'One', rank: 'a0' }, { id: 'L2', title: 'Two', rank: 'a1' }],
  cards: [{ id: 'c1', list: 'L1', rank: 'a0' }, { id: 'c2', list: 'L1', rank: 'a1' }, { id: 'c3', list: 'L1', rank: 'a2' }],
});
snapshot = snap0;
let fails = 0;
const ok = (name, cond) => { if (!cond) fails++; console.log(cond ? 'PASS' : 'FAIL', name); };
const order = (l) => S().cardsByList[l].join(',');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fresh = async () => { S().reset(); snapshot = snap0; await S().load('b1'); calls.length = 0; };

console.log('--- Week 2: optimistic local ops ---');
await fresh();
let p = S().moveCard('c1', 'L2', 0);
ok('move applied synchronously', order('L1') === 'c2,c3' && order('L2') === 'c1');
await p;
ok('move body (empty dest => no neighbours)', JSON.stringify(calls[0].body) === '{"listId":"L2","afterId":null,"beforeId":null}');
ok('server rank applied', S().cards.c1.rank === 'srv-rank');
failNext = 1; await S().moveCard('c2', 'L2', 1);
ok('failed move reverted + toast', order('L1') === 'c2,c3' && S().cards.c2.list === 'L1' && S().toast === 'boom');
await fresh(); delay = 5;
const add = S().addCard('L2', 'New'); const tmp = S().cardsByList.L2.at(-1);
const mv = S().moveCard(tmp, 'L1', 0);
await Promise.all([add, mv]); delay = 0;
ok('queued move used REAL id, after create', /cards\/real\d+\/move/.test(calls[1].url) && calls[0].url.endsWith('/cards'));
await fresh();
await S().updateCard('c1', { title: 'Hello' });
ok('updateCard really sends PATCH', calls[0]?.method === 'PATCH' && calls[0].body.title === 'Hello');
await fresh(); delay = 5; failNext = 1;
await Promise.all([S().updateCard('c1', { title: 'X' }), S().updateCard('c1', { description: 'Y' })]); delay = 0;
ok('fail with queued op => resync GET', calls.at(-1).method === 'GET');

console.log('--- Week 3: remote events ---');
const ev = (e, payload) => S().applyRemote(e, { boardId: 'b1', actor: 'other', ...payload });
await fresh();
ev('card:created', { card: { id: 'n1', list: 'L2', rank: 'a5', title: 'Remote' } });
ok('remote card:created appears', order('L2') === 'n1' && S().cards.n1.title === 'Remote');
ev('card:created', { card: { id: 'n1', list: 'L2', rank: 'a5' } });
ok('duplicate create ignored', order('L2') === 'n1');
ev('card:created', { card: { id: 'n2', list: 'L1', rank: 'a15', title: 'mid' } });
ok('created card inserted by rank (between a1 and a2)', order('L1') === 'c1,c2,n2,c3');
ev('card:moved', { card: { id: 'c1', list: 'L2', rank: 'a3' } });
ok('remote cross-list move', order('L1') === 'c2,n2,c3' && order('L2') === 'c1,n1' && S().cards.c1.list === 'L2');
ev('card:moved', { card: { id: 'c3', list: 'L1', rank: 'a05' } });
ok('remote within-list reorder by rank', order('L1') === 'c3,c2,n2'.replace('c3,c2,n2', 'c3,c2,n2'));
ev('card:moved', { card: { id: 'c2', list: 'L2', rank: 'a7' }, rebalanced: [{ id: 'n1', rank: 'b0' }, { id: 'c1', rank: 'a0' }] });
ok('rebalanced ranks applied; order consistent', S().cards.n1.rank === 'b0' && S().cards.c1.rank === 'a0');
ev('card:updated', { card: { id: 'n1', list: 'WRONG', rank: 'zzz', title: 'Edited' } });
ok('card:updated merges fields but not position', S().cards.n1.title === 'Edited' && S().cards.n1.list === 'L2' && S().cards.n1.rank === 'b0');
ev('card:updated', { card: { id: 'n1', archived: true } });
ok('archived card removed', !S().cards.n1 && !order('L2').includes('n1'));
S().openCard('c1'); ev('card:deleted', { cardId: 'c1' });
ok('remote delete removes card + closes its modal', !S().cards.c1 && S().openCardId === null);
ev('list:created', { list: { id: 'L3', title: 'New', rank: 'a2' } });
ok('remote list:created', S().listOrder.join() === 'L1,L2,L3' && S().cardsByList.L3.length === 0);
ev('list:moved', { list: { id: 'L3', rank: 'a05' } });
ok('remote list:moved', S().listOrder.join() === 'L1,L3,L2');
ev('list:updated', { list: { id: 'L3', title: 'Renamed', rank: 'ignored' } });
ok('list:updated merges title', S().lists.L3.title === 'Renamed' && S().lists.L3.rank === 'a05');
ev('list:deleted', { listId: 'L2' });
ok('remote list:deleted removes list + its cards', !S().lists.L2 && S().listOrder.join() === 'L1,L3' && !S().cards.c2);
ev('board:updated', { board: { title: 'Renamed board' } });
ok('board:updated', S().board.title === 'Renamed board');
S().applyRemote('card:created', { boardId: 'OTHER', card: { id: 'zz', list: 'L1', rank: 'a9' } });
ok('events for a different board ignored', !S().cards.zz);
calls.length = 0;
ev('card:moved', { card: { id: 'ghost', list: 'L1', rank: 'a9' } });
await sleep(20);
ok('event for unknown card triggers re-sync', calls.at(-1)?.method === 'GET');
ev('board:deleted', {});
ok('board:deleted surfaces error', S().error === 'This board was deleted');

console.log('--- Week 3: conflict handling (remote vs in-flight local op) ---');
await fresh(); delay = 20;
const local = S().moveCard('c1', 'L2', 0);                       // our drag, request in flight
ev('card:moved', { card: { id: 'c1', list: 'L1', rank: 'a15' } }); // someone else moved the SAME card
ok('remote event on in-flight entity is ignored (our optimistic view kept)', S().cards.c1.list === 'L2');
ev('card:moved', { card: { id: 'c3', list: 'L2', rank: 'a8' } });  // different card: applies immediately
ok('remote event on a different entity still applies', S().cards.c3.list === 'L2');
snapshot = () => ({ ...snap0(), cards: [{ id: 'c1', list: 'L1', rank: 'a0' }] }); // authoritative truth
await local; delay = 0; await sleep(50);
ok('queue drain triggers authoritative re-fetch', calls.at(-1).method === 'GET' && S().cards.c1.list === 'L1');
ok('state converged to server snapshot', Object.keys(S().cards).join() === 'c1');

console.log('--- Week 3: presence & typing ---');
await fresh();
S().setPresence([{ id: 'u1', name: 'Alice' }]);
ok('presence set', S().presence.length === 1);
S().setTyping({ cardId: 'c1', user: { id: 'u1', name: 'Alice' }, typing: true });
S().setTyping({ cardId: 'c1', user: { id: 'u2', name: 'Bob' }, typing: true });
ok('two users typing on a card', Object.values(S().typing.c1).sort().join() === 'Alice,Bob');
S().setTyping({ cardId: 'c1', user: { id: 'u1', name: 'Alice' }, typing: false });
ok('stop removes one user', Object.values(S().typing.c1).join() === 'Bob');
S().setTyping({ cardId: 'c1', user: { id: 'u2', name: 'Bob' }, typing: false });
ok('card entry removed when nobody typing', !('c1' in S().typing));
S().setTyping({ cardId: 'c1', user: { id: 'u1', name: 'Alice' }, typing: true }); S().clearTyping();
ok('clearTyping empties map', Object.keys(S().typing).length === 0);

console.log('--- Week 3: comments ---');
const C = () => useComments.getState();
await C().add('b1', 'c1', 'hello', { id: 'me', name: 'Me' });
ok('comment added + temp replaced', C().threads.c1.items.length === 1 && C().threads.c1.items[0].id.startsWith('cm'));
C().remoteAdded({ cardId: 'c1', comment: { id: 'r1', body: 'from bob', author: { id: 'u2', name: 'Bob' }, createdAt: new Date().toISOString() } });
C().remoteAdded({ cardId: 'c1', comment: { id: 'r1', body: 'dup' } });
ok('remote comment appended once (deduped)', C().threads.c1.items.map((c) => c.id).join() === C().threads.c1.items[0].id + ',r1');
C().remoteAdded({ cardId: 'unopened', comment: { id: 'x' } });
ok('remote comment for unopened thread ignored', !C().threads.unopened);
failNext = 1; await C().add('b1', 'c1', 'will fail', { id: 'me', name: 'Me' });
ok('failed comment rolled back', C().threads.c1.items.length === 2 && S().toast.startsWith('Comment not sent'));
C().remoteDeleted({ cardId: 'c1', commentId: 'r1' });
ok('remote comment delete', C().threads.c1.items.length === 1);
failNext = 1; const keep = C().threads.c1.items[0].id; await C().remove('b1', 'c1', keep);
ok('failed delete restored', C().threads.c1.items.length === 1);

console.log(fails ? `\n${fails} FAILED` : '\nall passed');
process.exit(fails ? 1 : 0);
