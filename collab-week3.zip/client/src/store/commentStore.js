import { create } from 'zustand';
import { api } from '../api/client.js';
import { useBoard } from './boardStore.js';

let n = 0;
const items = (s, cardId) => s.threads[cardId]?.items ?? [];
const put = (s, cardId, next) => ({ threads: { ...s.threads, [cardId]: { ...s.threads[cardId], items: next } } });

export const useComments = create((set, get) => ({
  threads: {}, // cardId -> { items, loading }

  async load(boardId, cardId, { silent = false } = {}) {
    if (!silent) set((s) => ({ threads: { ...s.threads, [cardId]: { items: [], loading: true } } }));
    try {
      const { comments } = await api(`/boards/${boardId}/cards/${cardId}/comments`);
      set((s) => ({ threads: { ...s.threads, [cardId]: { items: comments, loading: false } } }));
    } catch (e) {
      set((s) => ({ threads: { ...s.threads, [cardId]: { items: items(s, cardId), loading: false } } }));
      useBoard.getState().notify(e.message);
    }
  },

  async add(boardId, cardId, body, me) {
    const tmp = `tmp_c${++n}`;
    const draft = { id: tmp, card: cardId, body, createdAt: new Date().toISOString(), author: me, pending: true };
    set((s) => put(s, cardId, [...items(s, cardId), draft]));
    try {
      const { comment } = await api(`/boards/${boardId}/cards/${cardId}/comments`, { method: 'POST', body: { body } });
      set((s) => put(s, cardId, items(s, cardId).map((c) => (c.id === tmp ? comment : c))));
    } catch (e) {
      set((s) => put(s, cardId, items(s, cardId).filter((c) => c.id !== tmp)));
      useBoard.getState().notify(`Comment not sent: ${e.message}`);
    }
  },

  async remove(boardId, cardId, commentId) {
    const prev = items(get(), cardId);
    set((s) => put(s, cardId, items(s, cardId).filter((c) => c.id !== commentId)));
    try {
      await api(`/boards/${boardId}/comments/${commentId}`, { method: 'DELETE' });
    } catch (e) {
      set((s) => put(s, cardId, prev));
      useBoard.getState().notify(e.message);
    }
  },

  // from other users (the server never echoes our own)
  remoteAdded({ cardId, comment }) {
    if (!get().threads[cardId]) return; // thread not open; it loads fresh when opened
    set((s) => (items(s, cardId).some((c) => c.id === comment.id) ? s : put(s, cardId, [...items(s, cardId), comment])));
  },
  remoteDeleted({ cardId, commentId }) {
    if (get().threads[cardId]) set((s) => put(s, cardId, items(s, cardId).filter((c) => c.id !== commentId)));
  },
  clear: () => set({ threads: {} }),
}));
