import { create } from 'zustand';
import { generateKeyBetween } from 'fractional-indexing';
import { api } from '../api/client.js';

/*
 * Normalised board state with optimistic local ops AND remote (socket) events.
 *
 * Local ops: applied instantly, sent through a strict FIFO queue, reverted (or re-synced) on failure.
 * Remote ops: applied directly — UNLESS they touch an entity we have an in-flight local op for.
 *   In that case order is ambiguous (did the server see theirs or ours last?), so we drop the event
 *   and schedule one authoritative re-fetch for when our queue drains. State always converges.
 */

let seq = 0;
const newTmp = () => `tmp_${++seq}`;
const idMap = new Map(); // tmp id -> real id
const real = (id) => (id ? idMap.get(id) ?? id : id);

let pending = 0;
let chain = Promise.resolve();
let needsResync = false;
const touched = new Map(); // entity id -> number of in-flight local ops on it
const markTouched = (ids, d) =>
  ids.forEach((id) => {
    const n = (touched.get(id) ?? 0) + d;
    n > 0 ? touched.set(id, n) : touched.delete(id);
  });

const typingTimers = new Map();

const slice = (s) => ({ lists: s.lists, listOrder: s.listOrder, cards: s.cards, cardsByList: s.cardsByList });
const safeRank = (a, b, fallback) => {
  try {
    return generateKeyBetween(a, b);
  } catch {
    return fallback;
  }
};

// Ranks are order-preserving strings: plain string comparison matches the server's sort.
const sortsBefore = (a, idA, b, idB) => a.rank < b.rank || (a.rank === b.rank && idA < idB);
function insertSorted(ids, items, id) {
  const me = items[id];
  const rest = ids.filter((x) => x !== id);
  const i = rest.findIndex((x) => sortsBefore(me, id, items[x], x));
  return i < 0 ? [...rest, id] : [...rest.slice(0, i), id, ...rest.slice(i)];
}
function withRanks(store, rebalanced) {
  if (!rebalanced?.length) return store;
  const out = { ...store };
  rebalanced.forEach(({ id, rank }) => out[id] && (out[id] = { ...out[id], rank }));
  return out;
}

function build(data) {
  const lists = {};
  const cards = {};
  const cardsByList = {};
  data.lists.forEach((l) => {
    lists[l.id] = l;
    cardsByList[l.id] = [];
  });
  data.cards.forEach((c) => {
    cards[c.id] = c;
    cardsByList[c.list]?.push(c.id);
  });
  return {
    board: data.board, members: data.members, role: data.role,
    lists, listOrder: data.lists.map((l) => l.id), cards, cardsByList,
  };
}

const empty = {
  board: null, members: [], role: 'viewer', lists: {}, listOrder: [], cards: {}, cardsByList: {},
  loading: false, error: null, toast: null, openCardId: null, presence: [], typing: {},
};

export const useBoard = create((set, get) => {
  const boardPath = () => `/boards/${get().board.id}`;
  const resync = () => {
    if (pending > 0) needsResync = true;
    else get().load(get().board.id, { silent: true }).catch(() => {});
  };

  function run(apply, request, onSuccess, touch = []) {
    const snap = slice(get());
    set(apply(get()));
    pending++;
    markTouched(touch, 1);
    chain = chain.then(async () => {
      try {
        const res = await request(); // NB: not `onSuccess?.(await request())` — that skips the call when onSuccess is undefined
        onSuccess?.(res);
      } catch (e) {
        get().notify(e.message || 'Change failed and was reverted');
        if (pending > 1) needsResync = true;
        else set(snap);
      } finally {
        pending--;
        markTouched(touch, -1);
        if (pending === 0 && needsResync) {
          needsResync = false;
          await get().load(get().board.id, { silent: true }).catch(() => {});
        }
      }
    });
    return chain;
  }

  // Server-confirmed rank only; never overwrite local ordering made by later optimistic ops.
  const applyRanks = (res) =>
    set((s) => {
      const item = res.card ?? res.list;
      const key = res.card ? 'cards' : 'lists';
      const store = withRanks({ ...s[key], [item.id]: { ...s[key][item.id], rank: item.rank } }, res.rebalanced);
      return { [key]: store };
    });

  // ---- remote-apply helpers ----
  const dropCard = (id) =>
    set((s) => {
      const card = s.cards[id];
      if (!card) return {};
      const { [id]: _c, ...cards } = s.cards;
      return {
        cards,
        cardsByList: { ...s.cardsByList, [card.list]: (s.cardsByList[card.list] ?? []).filter((x) => x !== id) },
        openCardId: s.openCardId === id ? null : s.openCardId,
      };
    });
  const dropList = (id) =>
    set((s) => {
      if (!s.lists[id]) return {};
      const { [id]: _l, ...lists } = s.lists;
      const { [id]: cardIds = [], ...cardsByList } = s.cardsByList;
      const cards = { ...s.cards };
      cardIds.forEach((c) => delete cards[c]);
      return {
        lists, cardsByList, cards,
        listOrder: s.listOrder.filter((x) => x !== id),
        openCardId: cardIds.includes(s.openCardId) ? null : s.openCardId,
      };
    });
  const addRemoteCard = (c) => {
    if (!get().lists[c.list]) return resync();
    set((s) => {
      const cards = { ...s.cards, [c.id]: c };
      return { cards, cardsByList: { ...s.cardsByList, [c.list]: insertSorted(s.cardsByList[c.list], cards, c.id) } };
    });
  };

  return {
    ...empty,
    live: false,
    setLive: (live) => set({ live }),
    setPresence: (presence) => set({ presence }),

    setTyping({ cardId, user, typing }) {
      const key = `${cardId}|${user.id}`;
      clearTimeout(typingTimers.get(key));
      // client-side expiry too: a lost typing:stop must never leave a stuck indicator
      if (typing) typingTimers.set(key, setTimeout(() => get().setTyping({ cardId, user, typing: false }), 6000));
      else typingTimers.delete(key);
      set((s) => {
        const cur = { ...(s.typing[cardId] ?? {}) };
        if (typing) cur[user.id] = user.name;
        else delete cur[user.id];
        const next = { ...s.typing };
        if (Object.keys(cur).length) next[cardId] = cur;
        else delete next[cardId];
        return { typing: next };
      });
    },
    clearTyping: () => {
      typingTimers.forEach(clearTimeout);
      typingTimers.clear();
      set({ typing: {} });
    },

    notify: (msg) => {
      set({ toast: msg });
      setTimeout(() => get().toast === msg && set({ toast: null }), 4000);
    },
    openCard: (id) => set({ openCardId: id }),
    reset: () => {
      idMap.clear();
      touched.clear();
      pending = 0;
      needsResync = false;
      chain = Promise.resolve();
      get().clearTyping();
      set(empty);
    },

    async load(boardId, { silent = false } = {}) {
      if (!silent) set({ loading: true, error: null });
      try {
        set({ ...build(await api(`/boards/${boardId}`)), loading: false });
      } catch (e) {
        set({ error: e.message, loading: false });
        if (silent) throw e;
      }
    },

    // ---------- events from other users ----------
    applyRemote(event, p) {
      const s = get();
      if (!s.board || p.boardId !== s.board.id) return;
      const entity = p.card?.id ?? p.cardId ?? p.list?.id ?? p.listId;
      if (entity && touched.has(entity)) {
        needsResync = true; // we have an op in flight on this entity: let the re-fetch settle it
        return;
      }
      switch (event) {
        case 'card:created':
          if (!s.cards[p.card.id]) addRemoteCard(p.card);
          break;
        case 'card:updated': {
          const { list, rank, ...rest } = p.card; // position is owned by card:moved
          if (p.card.archived) dropCard(p.card.id);
          else if (!s.cards[p.card.id]) addRemoteCard(p.card);
          else set((st) => ({ cards: { ...st.cards, [p.card.id]: { ...st.cards[p.card.id], ...rest } } }));
          break;
        }
        case 'card:moved': {
          const c = p.card;
          const cur = s.cards[c.id];
          if (!cur || !s.lists[c.list]) return resync();
          set((st) => {
            let cards = withRanks(st.cards, p.rebalanced);
            cards = { ...cards, [c.id]: { ...cards[c.id], list: c.list, rank: c.rank } };
            const cardsByList = { ...st.cardsByList };
            cardsByList[cur.list] = (cardsByList[cur.list] ?? []).filter((x) => x !== c.id);
            cardsByList[c.list] = insertSorted(cardsByList[c.list], cards, c.id);
            return { cards, cardsByList };
          });
          break;
        }
        case 'card:deleted':
          dropCard(p.cardId);
          break;
        case 'list:created':
          if (s.lists[p.list.id]) break;
          set((st) => {
            const lists = { ...st.lists, [p.list.id]: p.list };
            return {
              lists,
              listOrder: insertSorted(st.listOrder, lists, p.list.id),
              cardsByList: { ...st.cardsByList, [p.list.id]: [] },
            };
          });
          break;
        case 'list:updated': {
          const { rank, ...rest } = p.list;
          if (p.list.archived) dropList(p.list.id);
          else if (s.lists[p.list.id]) set((st) => ({ lists: { ...st.lists, [p.list.id]: { ...st.lists[p.list.id], ...rest } } }));
          else resync();
          break;
        }
        case 'list:moved': {
          if (!s.lists[p.list.id]) return resync();
          set((st) => {
            let lists = withRanks(st.lists, p.rebalanced);
            lists = { ...lists, [p.list.id]: { ...lists[p.list.id], rank: p.list.rank } };
            return { lists, listOrder: insertSorted(st.listOrder, lists, p.list.id) };
          });
          break;
        }
        case 'list:deleted':
          dropList(p.listId);
          break;
        case 'board:updated':
          set((st) => ({ board: { ...st.board, ...p.board } }));
          break;
        case 'board:deleted':
          set({ error: 'This board was deleted' });
          break;
        default:
      }
    },

    // ---------- lists ----------
    addList(title) {
      const id = newTmp();
      const s = get();
      const last = s.lists[s.listOrder.at(-1)]?.rank ?? null;
      const list = { id, title, rank: safeRank(last, null, 'a0'), board: s.board.id, pending: true };
      return run(
        (st) => ({
          lists: { ...st.lists, [id]: list },
          listOrder: [...st.listOrder, id],
          cardsByList: { ...st.cardsByList, [id]: [] },
        }),
        () => api(`${boardPath()}/lists`, { method: 'POST', body: { title } }),
        ({ list: saved }) => {
          idMap.set(id, saved.id);
          set((st) => {
            const { [id]: _l, ...lists } = st.lists;
            const { [id]: cardIds = [], ...cardsByList } = st.cardsByList;
            const cards = { ...st.cards };
            cardIds.forEach((cid) => (cards[cid] = { ...cards[cid], list: saved.id }));
            return {
              lists: { ...lists, [saved.id]: saved },
              listOrder: st.listOrder.map((x) => (x === id ? saved.id : x)),
              cardsByList: { ...cardsByList, [saved.id]: cardIds },
              cards,
            };
          });
        },
        [id]
      );
    },

    renameList(id, title) {
      const prev = get().lists[id];
      if (!prev || prev.title === title) return;
      return run(
        (s) => ({ lists: { ...s.lists, [id]: { ...s.lists[id], title } } }),
        () => api(`${boardPath()}/lists/${real(id)}`, { method: 'PATCH', body: { title } }),
        undefined,
        [id]
      );
    },

    deleteList(id) {
      return run(
        (s) => {
          const { [id]: _l, ...lists } = s.lists;
          const { [id]: cardIds = [], ...cardsByList } = s.cardsByList;
          const cards = { ...s.cards };
          cardIds.forEach((c) => delete cards[c]);
          return { lists, cardsByList, cards, listOrder: s.listOrder.filter((x) => x !== id) };
        },
        () => api(`${boardPath()}/lists/${real(id)}`, { method: 'DELETE' }),
        undefined,
        [id]
      );
    },

    moveList(listId, toIndex) {
      const s = get();
      const order = s.listOrder.filter((x) => x !== listId);
      order.splice(toIndex, 0, listId);
      const afterId = order[toIndex - 1] ?? null;
      const beforeId = order[toIndex + 1] ?? null;
      const rank = safeRank(s.lists[afterId]?.rank ?? null, s.lists[beforeId]?.rank ?? null, s.lists[listId].rank);
      return run(
        (st) => ({ listOrder: order, lists: { ...st.lists, [listId]: { ...st.lists[listId], rank } } }),
        () =>
          api(`${boardPath()}/lists/${real(listId)}/move`, {
            method: 'POST',
            body: { afterId: real(afterId), beforeId: real(beforeId) },
          }),
        (res) => applyRanks({ list: res.list, rebalanced: res.rebalanced }),
        [listId]
      );
    },

    // ---------- cards ----------
    addCard(listId, title) {
      const id = newTmp();
      const s = get();
      const ids = s.cardsByList[listId] ?? [];
      const last = s.cards[ids.at(-1)]?.rank ?? null;
      const card = {
        id, title, description: '', list: listId, board: s.board.id,
        rank: safeRank(last, null, 'a0'), assignees: [], labels: [], pending: true,
      };
      return run(
        (st) => ({
          cards: { ...st.cards, [id]: card },
          cardsByList: { ...st.cardsByList, [listId]: [...(st.cardsByList[listId] ?? []), id] },
        }),
        () => api(`${boardPath()}/lists/${real(listId)}/cards`, { method: 'POST', body: { title } }),
        ({ card: saved }) => {
          idMap.set(id, saved.id);
          set((st) => {
            const { [id]: local, ...cards } = st.cards;
            const cardsByList = {};
            for (const [lid, arr] of Object.entries(st.cardsByList)) {
              cardsByList[lid] = arr.map((x) => (x === id ? saved.id : x));
            }
            return {
              cards: { ...cards, [saved.id]: { ...saved, list: local?.list ?? saved.list } },
              cardsByList,
              openCardId: st.openCardId === id ? saved.id : st.openCardId,
            };
          });
        },
        [id]
      );
    },

    updateCard(id, patch) {
      return run(
        (s) => ({ cards: { ...s.cards, [id]: { ...s.cards[id], ...patch } } }),
        () => api(`${boardPath()}/cards/${real(id)}`, { method: 'PATCH', body: patch }),
        undefined,
        [id]
      );
    },

    deleteCard(id) {
      return run(
        (s) => {
          const { [id]: card, ...cards } = s.cards;
          return {
            cards,
            cardsByList: { ...s.cardsByList, [card.list]: s.cardsByList[card.list].filter((x) => x !== id) },
            openCardId: s.openCardId === id ? null : s.openCardId,
          };
        },
        () => api(`${boardPath()}/cards/${real(id)}`, { method: 'DELETE' }),
        undefined,
        [id]
      );
    },

    moveCard(cardId, toListId, toIndex) {
      const s = get();
      const card = s.cards[cardId];
      if (!card) return;
      const fromListId = card.list;
      const dest = s.cardsByList[toListId].filter((x) => x !== cardId);
      dest.splice(toIndex, 0, cardId);
      const afterId = dest[toIndex - 1] ?? null;
      const beforeId = dest[toIndex + 1] ?? null;
      const rank = safeRank(s.cards[afterId]?.rank ?? null, s.cards[beforeId]?.rank ?? null, card.rank);
      return run(
        (st) => ({
          cards: { ...st.cards, [cardId]: { ...st.cards[cardId], list: toListId, rank } },
          cardsByList: {
            ...st.cardsByList,
            [fromListId]: st.cardsByList[fromListId].filter((x) => x !== cardId),
            [toListId]: dest,
          },
        }),
        () =>
          api(`${boardPath()}/cards/${real(cardId)}/move`, {
            method: 'POST',
            body: { listId: real(toListId), afterId: real(afterId), beforeId: real(beforeId) },
          }),
        (res) => applyRanks({ card: res.card, rebalanced: res.rebalanced }),
        [cardId]
      );
    },
  };
});
