import { useEffect, useState } from 'react';
import { useBoard } from '../store/boardStore.js';
import { useComments } from '../store/commentStore.js';
import { useAuth } from '../store/authStore.js';
import { useTyping } from '../socket/useTyping.js';

const initials = (name = '?') => name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();

export default function Comments({ cardId, canComment }) {
  const boardId = useBoard((s) => s.board?.id);
  const role = useBoard((s) => s.role);
  const typing = useBoard((s) => s.typing[cardId]);
  const thread = useComments((s) => s.threads[cardId]);
  const me = useAuth((s) => s.user);
  const [text, setText] = useState('');
  const { ping, stop } = useTyping(boardId, cardId);

  useEffect(() => {
    useComments.getState().load(boardId, cardId);
  }, [boardId, cardId]);

  const send = () => {
    const body = text.trim();
    if (!body) return;
    stop();
    setText('');
    useComments.getState().add(boardId, cardId, body, { id: me.id, name: me.name, avatar: me.avatar });
  };

  const names = typing ? Object.values(typing) : [];
  return (
    <section className="mt-5">
      <h3 className="text-xs font-semibold uppercase text-slate-500">Comments</h3>
      <div className="mt-2 max-h-56 space-y-3 overflow-y-auto pr-1">
        {thread?.loading && <p className="text-sm text-slate-400">Loading…</p>}
        {thread && !thread.loading && thread.items.length === 0 && <p className="text-sm text-slate-400">No comments yet.</p>}
        {thread?.items.map((c) => (
          <div key={c.id} className={`flex gap-2 ${c.pending ? 'opacity-50' : ''}`}>
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-indigo-500 text-[10px] font-semibold text-white">
              {initials(c.author.name)}
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-xs text-slate-500">
                <b className="text-slate-700">{c.author.name}</b> · {new Date(c.createdAt).toLocaleString()}
                {!c.pending && (c.author.id === me.id || role === 'admin') && (
                  <button onClick={() => useComments.getState().remove(boardId, cardId, c.id)} className="ml-2 text-slate-400 hover:text-red-600">delete</button>
                )}
              </div>
              <p className="whitespace-pre-wrap break-words text-sm">{c.body}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-1 h-4 text-xs text-indigo-600">
        {names.length > 0 && <span className="animate-pulse">{names.join(', ')} {names.length > 1 ? 'are' : 'is'} typing…</span>}
      </div>
      {canComment && (
        <div className="flex gap-2">
          <textarea value={text} rows={2} maxLength={5000} placeholder="Write a comment… (Enter to send, Shift+Enter for newline)"
            onChange={(e) => { setText(e.target.value); ping(); }} onBlur={stop}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            className="flex-1 rounded border border-slate-300 p-2 text-sm outline-none focus:border-blue-500" />
          <button onClick={send} disabled={!text.trim()} className="self-end rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700 disabled:opacity-40">Send</button>
        </div>
      )}
    </section>
  );
}
