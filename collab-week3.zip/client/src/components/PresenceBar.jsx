import { useBoard } from '../store/boardStore.js';
import { useAuth } from '../store/authStore.js';

const initials = (name = '?') => name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();

export default function PresenceBar() {
  const presence = useBoard((s) => s.presence);
  const live = useBoard((s) => s.live);
  const meId = useAuth((s) => s.user?.id);
  return (
    <div className="ml-auto flex items-center gap-3">
      <span className={`text-xs ${live ? 'text-green-200' : 'text-amber-200'}`} title={live ? 'Connected' : 'Offline — changes sync when you reconnect'}>
        {live ? '● Live' : '○ Offline'}
      </span>
      <div className="flex -space-x-1.5">
        {presence.map((u) => (
          <span key={u.id} title={u.id === meId ? `${u.name} (you)` : u.name}
            className="grid h-7 w-7 place-items-center rounded-full bg-indigo-400 text-[10px] font-semibold text-white ring-2 ring-blue-700">
            {initials(u.name)}
          </span>
        ))}
      </div>
    </div>
  );
}
