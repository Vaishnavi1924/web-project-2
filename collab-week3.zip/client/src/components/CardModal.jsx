import { useEffect, useState } from 'react';
import { useBoard } from '../store/boardStore.js';
import { useTyping } from '../socket/useTyping.js';
import Comments from './Comments.jsx';

export default function CardModal() {
  const id = useBoard((s) => s.openCardId);
  const card = useBoard((s) => s.cards[s.openCardId]);
  const members = useBoard((s) => s.members);
  const canEdit = useBoard((s) => s.role !== 'viewer');
  const boardId = useBoard((s) => s.board?.id);
  const typing = useBoard((s) => s.typing[s.openCardId]);
  const { ping, stop } = useTyping(boardId, id);
  const { openCard, updateCard, deleteCard } = useBoard.getState();
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');

  useEffect(() => {
    setTitle(card?.title ?? '');
    setDesc(card?.description ?? '');
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && openCard(null);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [openCard]);

  if (!card) return null;
  const saveTitle = () => title.trim() && title !== card.title && updateCard(id, { title: title.trim() });
  const saveDesc = () => {
    stop();
    if (desc !== card.description) updateCard(id, { description: desc });
  };
  const toggleAssignee = (uid) =>
    updateCard(id, {
      assignees: card.assignees.includes(uid) ? card.assignees.filter((x) => x !== uid) : [...card.assignees, uid],
    });

  return (
    <div className="fixed inset-0 z-50 grid place-items-start justify-center overflow-y-auto bg-black/40 p-6" onMouseDown={() => openCard(null)}>
      <div className="mt-10 w-full max-w-xl rounded-lg bg-white p-5 shadow-2xl" onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3">
          <input value={title} onChange={(e) => setTitle(e.target.value)} onBlur={saveTitle} disabled={!canEdit}
            className="flex-1 rounded border border-transparent px-1 text-lg font-semibold outline-none hover:border-slate-300 focus:border-blue-500" />
          <button onClick={() => openCard(null)} className="text-slate-500 hover:text-slate-900" aria-label="Close">✕</button>
        </div>

        <label className="mt-4 block text-xs font-semibold uppercase text-slate-500">Description</label>
        {typing && <p className="mt-1 animate-pulse text-xs text-indigo-600">✎ {Object.values(typing).join(', ')} typing on this card — last save wins</p>}
        <textarea value={desc} onChange={(e) => { setDesc(e.target.value); ping(); }} onBlur={saveDesc} disabled={!canEdit} rows={5}
          placeholder="Add a more detailed description…"
          className="mt-1 w-full rounded border border-slate-300 p-2 text-sm outline-none focus:border-blue-500" />

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase text-slate-500">Due date</label>
            <input type="date" disabled={!canEdit}
              value={card.dueDate ? new Date(card.dueDate).toISOString().slice(0, 10) : ''}
              onChange={(e) => updateCard(id, { dueDate: e.target.value ? new Date(e.target.value).toISOString() : null })}
              className="mt-1 w-full rounded border border-slate-300 p-1.5 text-sm" />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase text-slate-500">Assignees</label>
            <div className="mt-1 max-h-28 overflow-y-auto rounded border border-slate-300 p-1">
              {members.map((m) => (
                <label key={m.id} className="flex items-center gap-2 px-1 py-0.5 text-sm">
                  <input type="checkbox" disabled={!canEdit || card.pending} checked={card.assignees.includes(m.id)} onChange={() => toggleAssignee(m.id)} />
                  {m.name}
                </label>
              ))}
            </div>
          </div>
        </div>

        {!card.pending && <Comments cardId={id} canComment={canEdit} />}

        {canEdit && (
          <button onClick={() => confirm('Delete this card?') && deleteCard(id)}
            className="mt-5 rounded bg-red-50 px-3 py-1.5 text-sm text-red-700 hover:bg-red-100">Delete card</button>
        )}
      </div>
    </div>
  );
}
