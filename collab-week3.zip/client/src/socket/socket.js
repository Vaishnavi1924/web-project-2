import { io } from 'socket.io-client';
import { useAuth } from '../store/authStore.js';
import { useBoard } from '../store/boardStore.js';
import { useComments } from '../store/commentStore.js';
import { refreshSession } from '../api/client.js';
import { setSocketId } from './id.js';

// `auth` is a function so every (re)connect handshake carries the *current* access token.
export const socket = io({
  autoConnect: false,
  auth: (cb) => cb({ token: useAuth.getState().token }),
});

let currentBoard = null;
let refreshing = false;

const BOARD_EVENTS = [
  'card:created', 'card:updated', 'card:moved', 'card:deleted',
  'list:created', 'list:updated', 'list:moved', 'list:deleted',
  'board:updated', 'board:deleted',
];
BOARD_EVENTS.forEach((ev) => socket.on(ev, (p) => useBoard.getState().applyRemote(ev, p)));
socket.on('comment:added', (p) => p.boardId === currentBoard && useComments.getState().remoteAdded(p));
socket.on('comment:deleted', (p) => p.boardId === currentBoard && useComments.getState().remoteDeleted(p));
socket.on('presence:update', (p) => p.boardId === currentBoard && useBoard.getState().setPresence(p.users));
socket.on('typing:update', (p) => p.boardId === currentBoard && useBoard.getState().setTyping(p));

const NOTE_TEXT = {
  assigned: 'You were assigned to a card',
  commented: 'New comment on a card you follow',
  invited: 'You were invited to a workspace',
};
socket.on('notification:new', (n) => useBoard.getState().notify(NOTE_TEXT[n.type] ?? 'New notification'));

function joinAck(boardId) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve({ ok: false, error: 'timeout' }), 5000);
    socket.emit('board:join', { boardId }, (res) => {
      clearTimeout(timer);
      resolve(res);
    });
  });
}

// Fires on first connect AND every reconnect. Rejoin the room, then re-fetch the snapshot to
// cover anything broadcast while we were offline (Socket.io does not replay missed events).
socket.on('connect', async () => {
  setSocketId(socket.id);
  useBoard.getState().setLive(true);
  if (!currentBoard) return;
  const res = await joinAck(currentBoard);
  if (!res.ok) return useBoard.getState().notify(`Live updates unavailable: ${res.error}`);
  useBoard.getState().setPresence(res.presence ?? []);
  if (useBoard.getState().board?.id === currentBoard) {
    useBoard.getState().load(currentBoard, { silent: true }).catch(() => {});
    const open = useBoard.getState().openCardId;
    if (open && !open.startsWith('tmp_')) useComments.getState().load(currentBoard, open, { silent: true });
  }
});

socket.on('disconnect', () => {
  setSocketId(null);
  useBoard.getState().setLive(false);
  useBoard.getState().setPresence([]);
  useBoard.getState().clearTyping();
});

// Middleware rejections are not auto-retried by Socket.io. Expired token => refresh, then reconnect once.
socket.on('connect_error', async (err) => {
  if (err.message !== 'Unauthorized' || refreshing) return;
  refreshing = true;
  const ok = await refreshSession();
  refreshing = false;
  if (ok) socket.connect();
});

export const connectSocket = () => !socket.active && socket.connect();
export const disconnectSocket = () => {
  currentBoard = null;
  socket.disconnect();
};

/** Join the room first, THEN load the snapshot, so no event can fall into the gap between them. */
export async function enterBoard(boardId) {
  currentBoard = boardId;
  if (socket.connected) {
    const res = await joinAck(boardId);
    if (res.ok) useBoard.getState().setPresence(res.presence ?? []);
  } // else the 'connect' handler joins + resyncs once we're online
  await useBoard.getState().load(boardId);
}

export function leaveBoard() {
  if (currentBoard && socket.connected) socket.emit('board:leave', { boardId: currentBoard });
  currentBoard = null;
  useComments.getState().clear();
  useBoard.getState().setPresence([]);
}

export const emitTyping = (boardId, cardId, on) =>
  socket.connected && socket.emit(on ? 'typing:start' : 'typing:stop', { boardId, cardId });
