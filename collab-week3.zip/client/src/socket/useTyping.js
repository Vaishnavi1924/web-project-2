import { useCallback, useEffect, useRef } from 'react';
import { emitTyping } from './socket.js';

/** ping() on every keystroke: emits typing:start at most every 2s, typing:stop after 3s idle / blur / unmount. */
export function useTyping(boardId, cardId) {
  const last = useRef(0);
  const timer = useRef(null);

  const stop = useCallback(() => {
    clearTimeout(timer.current);
    if (last.current) {
      last.current = 0;
      emitTyping(boardId, cardId, false);
    }
  }, [boardId, cardId]);

  const ping = useCallback(() => {
    const now = Date.now();
    if (now - last.current > 2000) {
      last.current = now;
      emitTyping(boardId, cardId, true);
    }
    clearTimeout(timer.current);
    timer.current = setTimeout(stop, 3000);
  }, [boardId, cardId, stop]);

  useEffect(() => stop, [stop]);
  return { ping, stop };
}
