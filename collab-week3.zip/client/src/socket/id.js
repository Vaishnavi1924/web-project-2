// Tiny module so api/client.js can read the socket id without importing the socket (avoids a cycle).
let id = null;
export const setSocketId = (v) => { id = v; };
export const getSocketId = () => id;
