import { useAuth } from '../store/authStore.js';
import { getSocketId } from '../socket/id.js';

let refreshing = null;

/** Single-flight refresh so parallel 401s trigger only one /auth/refresh call. */
export function refreshSession() {
  refreshing ??= fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
    .then(async (r) => {
      if (!r.ok) {
        useAuth.getState().clear();
        return false;
      }
      useAuth.getState().setSession(await r.json());
      return true;
    })
    .catch(() => false)
    .finally(() => {
      refreshing = null;
    });
  return refreshing;
}

export async function api(path, { method = 'GET', body } = {}) {
  const send = () =>
    fetch(`/api${path}`, {
      method,
      credentials: 'include',
      headers: {
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(useAuth.getState().token ? { Authorization: `Bearer ${useAuth.getState().token}` } : {}),
        // lets the server skip echoing our own changes back to us
        ...(getSocketId() ? { 'X-Socket-Id': getSocketId() } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });

  let res = await send();
  if (res.status === 401 && !path.startsWith('/auth/')) {
    if (await refreshSession()) res = await send();
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: res.status });
  return data;
}
