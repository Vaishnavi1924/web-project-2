import http from 'node:http';
import { env } from './config/env.js';
import { connectDB } from './config/db.js';
import { createApp } from './app.js';
import { initSocket } from './sockets/index.js';

await connectDB();
const server = http.createServer(createApp());
initSocket(server);
server.listen(env.port, () => console.log(`API listening on :${env.port}`));
