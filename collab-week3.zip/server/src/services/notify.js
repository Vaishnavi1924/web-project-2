import Notification from '../models/Notification.js';
import { dto } from '../utils/dto.js';
import { emitToUser } from '../sockets/emit.js';

/** Persist notifications, then push each to the recipient's live sockets. */
export async function notifyUsers(userIds, { type, refs }) {
  const unique = [...new Set(userIds.map(String))];
  if (!unique.length) return [];
  const docs = await Notification.insertMany(unique.map((user) => ({ user, type, refs })));
  docs.forEach((d) => emitToUser(d.user, 'notification:new', dto(d)));
  return docs;
}
