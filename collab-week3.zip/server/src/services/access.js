import Board from '../models/Board.js';
import Workspace from '../models/Workspace.js';
import { RANK } from '../middleware/workspace.js';
import { HttpError } from '../utils/http.js';
import { isId } from '../utils/mongo.js';

/** Single source of truth for "may this user touch this board?" — REST and Socket.io both call it. */
export async function getBoardAccess(userId, boardId, minRole = 'viewer') {
  if (!isId(boardId)) throw new HttpError(400, 'Invalid board id');
  const board = await Board.findById(boardId);
  if (!board) throw new HttpError(404, 'Board not found');
  const workspace = await Workspace.findById(board.workspace).select('members owner');
  const m = workspace?.members.find((x) => String(x.user) === String(userId));
  if (!m) throw new HttpError(403, 'Not a member of this workspace');
  if (RANK[m.role] < RANK[minRole]) throw new HttpError(403, 'Insufficient permissions');
  return { board, workspace, role: m.role };
}
