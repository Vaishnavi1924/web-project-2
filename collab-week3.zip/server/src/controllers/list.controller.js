import { z } from 'zod';
import List from '../models/List.js';
import { HttpError, wrap } from '../utils/http.js';
import { dto } from '../utils/dto.js';
import { isId } from '../utils/mongo.js';
import { computeRank } from '../services/rank.js';
import { deleteListCascade } from '../services/cascade.js';
import { emitToBoard } from '../sockets/emit.js';

const objectId = z.string().regex(/^[a-f\d]{24}$/i);

export const listCreateSchema = z.object({ title: z.string().trim().min(1).max(120) });
export const listUpdateSchema = z.object({
  title: z.string().trim().min(1).max(120).optional(),
  archived: z.boolean().optional(),
});
export const listMoveSchema = z.object({
  afterId: objectId.nullish(),
  beforeId: objectId.nullish(),
  opId: z.string().max(64).optional(),
});

export async function loadList(boardId, listId) {
  if (!isId(listId)) throw new HttpError(400, 'Invalid list id');
  const list = await List.findOne({ _id: listId, board: boardId });
  if (!list) throw new HttpError(404, 'List not found');
  return list;
}

export const createList = wrap(async (req, res) => {
  const { rank } = await computeRank(List, { board: req.board._id });
  const list = await List.create({ board: req.board._id, title: req.body.title, rank });
  emitToBoard(req, 'list:created', { list: dto(list) });
  res.status(201).json({ list: dto(list) });
});

export const updateList = wrap(async (req, res) => {
  const list = await loadList(req.board._id, req.params.listId);
  Object.assign(list, req.body);
  await list.save();
  emitToBoard(req, 'list:updated', { list: dto(list) });
  res.json({ list: dto(list) });
});

export const moveList = wrap(async (req, res) => {
  const list = await loadList(req.board._id, req.params.listId);
  const { afterId, beforeId, opId } = req.body;
  const { rank, rebalanced } = await computeRank(List, { board: req.board._id }, { afterId, beforeId, excludeId: list._id });
  list.rank = rank;
  await list.save();
  emitToBoard(req, 'list:moved', { list: dto(list), rebalanced, opId });
  res.json({ list: dto(list), rebalanced, opId });
});

export const deleteList = wrap(async (req, res) => {
  const list = await loadList(req.board._id, req.params.listId);
  await deleteListCascade(list._id);
  emitToBoard(req, 'list:deleted', { listId: String(list._id) });
  res.status(204).end();
});
