import { z } from 'zod';
import Card from '../models/Card.js';
import Comment from '../models/Comment.js';
import { HttpError, wrap } from '../utils/http.js';
import { isId } from '../utils/mongo.js';
import { emitToBoard } from '../sockets/emit.js';
import { notifyUsers } from '../services/notify.js';

export const commentSchema = z.object({ body: z.string().trim().min(1).max(5000) });

export const commentDto = (c) => ({
  id: String(c._id),
  card: String(c.card),
  body: c.body,
  createdAt: c.createdAt,
  author: { id: String(c.author._id ?? c.author), name: c.author.name, avatar: c.author.avatar },
});

async function loadCard(boardId, cardId) {
  if (!isId(cardId)) throw new HttpError(400, 'Invalid card id');
  const card = await Card.findOne({ _id: cardId, board: boardId });
  if (!card) throw new HttpError(404, 'Card not found');
  return card;
}

export const listComments = wrap(async (req, res) => {
  const card = await loadCard(req.board._id, req.params.cardId);
  const comments = await Comment.find({ card: card._id }).sort({ createdAt: 1, _id: 1 }).limit(500)
    .populate('author', 'name avatar').lean();
  res.json({ comments: comments.map(commentDto) });
});

export const addComment = wrap(async (req, res) => {
  const card = await loadCard(req.board._id, req.params.cardId);
  const comment = await Comment.create({ card: card._id, author: req.user._id, body: req.body.body });
  await comment.populate('author', 'name avatar');
  const out = commentDto(comment);

  emitToBoard(req, 'comment:added', { cardId: String(card._id), comment: out });
  const audience = [...card.assignees, card.createdBy].filter(Boolean).map(String)
    .filter((id) => id !== String(req.user._id));
  await notifyUsers(audience, {
    type: 'commented',
    refs: { workspace: req.workspace._id, board: req.board._id, card: card._id, actor: req.user._id },
  });
  res.status(201).json({ comment: out });
});

export const deleteComment = wrap(async (req, res) => {
  const { commentId } = req.params;
  if (!isId(commentId)) throw new HttpError(400, 'Invalid comment id');
  const comment = await Comment.findById(commentId);
  const card = comment && (await Card.findOne({ _id: comment.card, board: req.board._id }).select('_id'));
  if (!comment || !card) throw new HttpError(404, 'Comment not found');
  if (String(comment.author) !== String(req.user._id) && req.role !== 'admin') {
    throw new HttpError(403, 'Only the author or an admin can delete a comment');
  }
  await comment.deleteOne();
  emitToBoard(req, 'comment:deleted', { cardId: String(card._id), commentId });
  res.status(204).end();
});
