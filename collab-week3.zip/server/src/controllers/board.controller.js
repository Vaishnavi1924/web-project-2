import { z } from 'zod';
import { generateNKeysBetween } from 'fractional-indexing';
import Board from '../models/Board.js';
import List from '../models/List.js';
import Card from '../models/Card.js';
import Workspace from '../models/Workspace.js';
import { wrap } from '../utils/http.js';
import { dto } from '../utils/dto.js';
import { deleteBoardsCascade } from '../services/cascade.js';
import { emitToBoard } from '../sockets/emit.js';

export const boardSchema = z.object({
  title: z.string().trim().min(1).max(120),
  description: z.string().max(1000).optional(),
});
export const boardUpdateSchema = boardSchema.partial().extend({ archived: z.boolean().optional() });

export const listBoards = wrap(async (req, res) => {
  const boards = await Board.find({ workspace: req.workspace._id, archived: false }).sort('-updatedAt').lean();
  res.json({ boards: boards.map(dto) });
});

export const createBoard = wrap(async (req, res) => {
  const board = await Board.create({ ...req.body, workspace: req.workspace._id, createdBy: req.user._id });
  const titles = ['To do', 'In progress', 'Done'];
  const ranks = generateNKeysBetween(null, null, titles.length);
  await List.insertMany(titles.map((title, i) => ({ board: board._id, title, rank: ranks[i] })));
  res.status(201).json({ board: dto(board) });
});

/** Full snapshot: everything a client needs to render (and later, re-sync) a board. */
export const getBoard = wrap(async (req, res) => {
  const [lists, cards, ws] = await Promise.all([
    List.find({ board: req.board._id, archived: false }).sort({ rank: 1, _id: 1 }).lean(),
    Card.find({ board: req.board._id, archived: false }).sort({ rank: 1, _id: 1 }).lean(),
    Workspace.findById(req.board.workspace).populate('members.user', 'name email avatar').lean(),
  ]);
  const members = ws.members
    .filter((m) => m.user)
    .map((m) => ({ id: String(m.user._id), name: m.user.name, email: m.user.email, avatar: m.user.avatar, role: m.role }));
  res.json({ board: dto(req.board), lists: lists.map(dto), cards: cards.map(dto), members, role: req.role });
});

export const updateBoard = wrap(async (req, res) => {
  Object.assign(req.board, req.body);
  await req.board.save();
  emitToBoard(req, 'board:updated', { board: dto(req.board) });
  res.json({ board: dto(req.board) });
});

export const deleteBoard = wrap(async (req, res) => {
  await deleteBoardsCascade([req.board._id]);
  emitToBoard(req, 'board:deleted', {});
  res.status(204).end();
});
