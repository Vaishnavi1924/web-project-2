import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { requireBoardRole as role } from '../middleware/board.js';
import { validate } from '../middleware/validate.js';
import * as b from '../controllers/board.controller.js';
import * as l from '../controllers/list.controller.js';
import * as c from '../controllers/card.controller.js';
import * as m from '../controllers/comment.controller.js';

const r = Router();
r.use(requireAuth);

r.get('/:boardId', role('viewer'), b.getBoard);
r.patch('/:boardId', role('member'), validate(b.boardUpdateSchema), b.updateBoard);
r.delete('/:boardId', role('admin'), b.deleteBoard);

r.post('/:boardId/lists', role('member'), validate(l.listCreateSchema), l.createList);
r.patch('/:boardId/lists/:listId', role('member'), validate(l.listUpdateSchema), l.updateList);
r.post('/:boardId/lists/:listId/move', role('member'), validate(l.listMoveSchema), l.moveList);
r.delete('/:boardId/lists/:listId', role('member'), l.deleteList);

r.post('/:boardId/lists/:listId/cards', role('member'), validate(c.cardCreateSchema), c.createCard);
r.get('/:boardId/cards/:cardId', role('viewer'), c.getCard);
r.patch('/:boardId/cards/:cardId', role('member'), validate(c.cardUpdateSchema), c.updateCard);
r.post('/:boardId/cards/:cardId/move', role('member'), validate(c.cardMoveSchema), c.moveCard);
r.delete('/:boardId/cards/:cardId', role('member'), c.deleteCard);

r.get('/:boardId/cards/:cardId/comments', role('viewer'), m.listComments);
r.post('/:boardId/cards/:cardId/comments', role('member'), validate(m.commentSchema), m.addComment);
r.delete('/:boardId/comments/:commentId', role('member'), m.deleteComment);

export default r;
