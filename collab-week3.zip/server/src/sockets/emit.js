let io = null;
export const setIO = (instance) => {
  io = instance;
};
export const boardRoom = (id) => `board:${id}`;
export const userRoom = (id) => `user:${id}`;

/**
 * Broadcast a committed change to everyone viewing the board EXCEPT the socket that made it.
 * The client sends its socket id in `X-Socket-Id`, so the originator (who already applied the
 * change optimistically) never gets an echo.
 */
export function emitToBoard(req, event, data) {
  if (!io) return;
  const sid = req.get('x-socket-id');
  const target = io.to(boardRoom(req.board._id));
  (sid ? target.except(sid) : target).emit(event, {
    ...data,
    boardId: String(req.board._id),
    actor: String(req.user._id),
  });
}

export const emitToUser = (userId, event, data) => io?.to(userRoom(userId)).emit(event, data);

/** Force a user's sockets to drop; on reconnect every board:join is re-authorised. */
export const kickUser = (userId) => io?.in(userRoom(userId)).disconnectSockets(true);
