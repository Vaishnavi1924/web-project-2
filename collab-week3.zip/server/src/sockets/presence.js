// boardId -> Map(userId -> { user, sockets:Set }). A user with 3 tabs counts once.
// Single-process for now; Week 4 swaps this for a Redis set so it works across instances.
const boards = new Map();

export function add(boardId, socketId, user) {
  if (!boards.has(boardId)) boards.set(boardId, new Map());
  const users = boards.get(boardId);
  const isNewUser = !users.has(user.id);
  if (isNewUser) users.set(user.id, { user, sockets: new Set() });
  users.get(user.id).sockets.add(socketId);
  return isNewUser; // true => the visible list changed
}

export function remove(boardId, socketId, userId) {
  const users = boards.get(boardId);
  const entry = users?.get(userId);
  if (!entry) return false;
  entry.sockets.delete(socketId);
  if (entry.sockets.size) return false;
  users.delete(userId);
  if (!users.size) boards.delete(boardId);
  return true; // user fully left
}

export const list = (boardId) =>
  [...(boards.get(boardId)?.values() ?? [])].map(({ user }) => ({ id: user.id, name: user.name, avatar: user.avatar }));
