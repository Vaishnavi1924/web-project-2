import { Server } from 'socket.io';
import { env } from '../config/env.js';
import User from '../models/User.js';
import { verifyAccess } from '../utils/tokens.js';
import { getBoardAccess } from '../services/access.js';
import { isId } from '../utils/mongo.js';
import { setIO, boardRoom, userRoom } from './emit.js';
import * as presence from './presence.js';

const MAX_BOARDS_PER_SOCKET = 20;

// Injectable so the socket layer can be tested without MongoDB.
const defaultDeps = {
  authenticate: async (token) => {
    const { sub } = verifyAccess(token);
    const u = await User.findById(sub).select('name avatar').lean();
    return u && { id: String(u._id), name: u.name, avatar: u.avatar };
  },
  authorize: async (userId, boardId) => (await getBoardAccess(userId, boardId)).role,
  typingTtlMs: 5000,
};

export function initSocket(httpServer, overrides = {}) {
  const deps = { ...defaultDeps, ...overrides };
  const io = new Server(httpServer, { cors: { origin: env.clientOrigin, credentials: true } });
  setIO(io);

  // Secure handshake: the JWT must be valid BEFORE the connection is established.
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      const user = token ? await deps.authenticate(token) : null;
      if (!user) return next(new Error('Unauthorized'));
      Object.assign(socket.data, { user, boards: new Set(), typing: new Map() });
      next();
    } catch {
      next(new Error('Unauthorized'));
    }
  });

  const emitPresence = (boardId) =>
    io.to(boardRoom(boardId)).emit('presence:update', { boardId, users: presence.list(boardId) });

  io.on('connection', (socket) => {
    const { user } = socket.data;
    socket.join(userRoom(user.id)); // personal channel for notification:new

    const emitTyping = (boardId, cardId, on) =>
      io.to(boardRoom(boardId)).except(socket.id).emit('typing:update', {
        boardId, cardId, user: { id: user.id, name: user.name }, typing: on,
      });

    // Typing has a server-side TTL: if the client dies mid-sentence the indicator still clears.
    const setTyping = (boardId, cardId, on) => {
      const key = `${boardId}|${cardId}`;
      const had = socket.data.typing.has(key);
      clearTimeout(socket.data.typing.get(key));
      if (on) {
        socket.data.typing.set(key, setTimeout(() => {
          socket.data.typing.delete(key);
          emitTyping(boardId, cardId, false);
        }, deps.typingTtlMs));
      } else {
        socket.data.typing.delete(key);
        if (!had) return;
      }
      emitTyping(boardId, cardId, on);
    };

    const clearTypingFor = (boardId) => {
      for (const key of [...socket.data.typing.keys()]) {
        if (key.startsWith(`${boardId}|`)) setTyping(boardId, key.split('|')[1], false);
      }
    };

    const leave = (boardId) => {
      if (!socket.data.boards.delete(boardId)) return;
      clearTypingFor(boardId);
      socket.leave(boardRoom(boardId));
      if (presence.remove(boardId, socket.id, user.id)) emitPresence(boardId);
    };

    socket.on('board:join', async (payload, ack) => {
      const reply = typeof ack === 'function' ? ack : () => {};
      const boardId = payload?.boardId;
      if (!isId(boardId)) return reply({ ok: false, error: 'Invalid board id' });
      if (!socket.data.boards.has(boardId) && socket.data.boards.size >= MAX_BOARDS_PER_SOCKET) {
        return reply({ ok: false, error: 'Too many boards open' });
      }
      try {
        const role = await deps.authorize(user.id, boardId); // membership re-checked on EVERY join
        if (socket.disconnected) return;
        socket.join(boardRoom(boardId));
        socket.data.boards.add(boardId);
        if (presence.add(boardId, socket.id, user)) emitPresence(boardId);
        reply({ ok: true, role, presence: presence.list(boardId) });
      } catch (e) {
        reply({ ok: false, error: e.status === 403 || e.status === 404 ? 'Forbidden' : 'Could not join board' });
      }
    });

    socket.on('board:leave', (payload) => isId(payload?.boardId) && leave(payload.boardId));

    const typingHandler = (on) => (payload) => {
      const { boardId, cardId } = payload ?? {};
      if (!isId(boardId) || !isId(cardId) || !socket.data.boards.has(boardId)) return; // must have joined
      setTyping(boardId, cardId, on);
    };
    socket.on('typing:start', typingHandler(true));
    socket.on('typing:stop', typingHandler(false));

    socket.on('disconnect', () => {
      for (const boardId of [...socket.data.boards]) leave(boardId);
    });
  });

  return io;
}
