import { getBoardAccess } from '../services/access.js';
import { wrap } from '../utils/http.js';

/** Loads :boardId and checks the user's role. Sets req.board / req.workspace / req.role. */
export const requireBoardRole = (minRole = 'viewer') =>
  wrap(async (req, _res, next) => {
    const { board, workspace, role } = await getBoardAccess(req.user._id, req.params.boardId, minRole);
    Object.assign(req, { board, workspace, role });
    next();
  });
