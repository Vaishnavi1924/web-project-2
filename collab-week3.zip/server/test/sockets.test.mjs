// Run: node test/sockets.test.mjs   (no MongoDB needed; auth/authorize are stubbed)
process.env.JWT_ACCESS_SECRET = 'a'; process.env.JWT_REFRESH_SECRET = 'b';
process.env.MONGO_URI = 'x'; process.env.CLIENT_ORIGIN = 'http://x';
import http from 'node:http';
import { io as connect } from 'socket.io-client';
const { initSocket } = await import('../src/sockets/index.js');
const { emitToBoard, kickUser } = await import('../src/sockets/emit.js');

const B1 = 'a'.repeat(24), B2 = 'b'.repeat(24), CARD = 'c'.repeat(24);
const USERS = { alice: { id: 'u1', name: 'Alice' }, bob: { id: 'u2', name: 'Bob' }, carol: { id: 'u3', name: 'Carol' } };
const server = http.createServer();
initSocket(server, {
  authenticate: async (t) => USERS[t] ?? null,
  authorize: async (uid, bid) => { if (bid === B2) throw Object.assign(new Error('no'), { status: 403 }); return 'member'; },
  typingTtlMs: 150,
});
await new Promise((r) => server.listen(0, r));
const url = `http://localhost:${server.address().port}`;

let fails = 0;
const ok = (n, c) => { if (!c) fails++; console.log(c ? 'PASS' : 'FAIL', n); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const client = (token) => new Promise((res, rej) => {
  const s = connect(url, { auth: { token }, transports: ['websocket'], reconnection: false });
  s.log = {};
  s.onAny((ev, p) => (s.log[ev] ??= []).push(p));
  s.on('connect', () => res(s)); s.on('connect_error', (e) => rej(e));
});
const join = (s, boardId) => new Promise((r) => s.emit('board:join', { boardId }, r));

// 1. handshake
await client(undefined).then(() => ok('no token rejected', false), (e) => ok('no token rejected', e.message === 'Unauthorized'));
await client('forged').then(() => ok('bad token rejected', false), (e) => ok('bad token rejected', e.message === 'Unauthorized'));

// 2. join + presence
const alice = await client('alice'), bob = await client('bob'), carol = await client('carol');
const a1 = await join(alice, B1);
ok('alice joins, sees only herself', a1.ok && a1.presence.length === 1 && a1.role === 'member');
const b1 = await join(bob, B1);
await sleep(30);
ok('bob joins, ack lists both', b1.ok && b1.presence.map((u) => u.name).sort().join() === 'Alice,Bob');
ok('alice got presence:update with both', alice.log['presence:update'].at(-1).users.length === 2);

// 3. authorisation on join
const denied = await join(carol, B2);
ok('forbidden board refused', denied.ok === false && denied.error === 'Forbidden');
ok('invalid id refused', (await join(carol, 'nope')).ok === false);

// 4. broadcast excludes the originating socket
const fakeReq = (sid) => ({ get: (h) => (h === 'x-socket-id' ? sid : undefined), board: { _id: B1 }, user: { _id: 'u1' } });
emitToBoard(fakeReq(alice.id), 'card:moved', { card: { id: 'x' } });
await sleep(50);
ok('bob receives card:moved (with boardId + actor)', bob.log['card:moved']?.[0]?.boardId === B1 && bob.log['card:moved'][0].actor === 'u1');
ok('alice (originator) gets NO echo', !alice.log['card:moved']);
emitToBoard(fakeReq(undefined), 'card:updated', { card: { id: 'y' } });
await sleep(50);
ok('without header everyone gets it', alice.log['card:updated']?.length === 1 && bob.log['card:updated']?.length === 1);
ok('non-member socket never receives board events', !carol.log['card:moved'] && !carol.log['card:updated']);

// 5. typing
alice.emit('typing:start', { boardId: B1, cardId: CARD });
await sleep(50);
const t = bob.log['typing:update']?.[0];
ok('bob sees alice typing', t?.typing === true && t.user.name === 'Alice' && t.cardId === CARD);
ok('alice not told about own typing', !alice.log['typing:update']);
await sleep(250); // > TTL, no stop sent
ok('server TTL auto-clears typing', bob.log['typing:update'].at(-1).typing === false);
carol.emit('typing:start', { boardId: B1, cardId: CARD }); // carol never joined B1
await sleep(50);
ok('typing from non-joined socket ignored', bob.log['typing:update'].length === 2);
alice.emit('typing:stop', { boardId: B1, cardId: CARD });
await sleep(50);
ok('stop without start emits nothing', bob.log['typing:update'].length === 2);

// 6. disconnect cleans typing + presence; multi-tab counts once
alice.emit('typing:start', { boardId: B1, cardId: CARD });
await sleep(30);
const before = bob.log['typing:update'].length;
alice.disconnect();
await sleep(60);
ok('disconnect clears live typing', bob.log['typing:update'].length === before + 1 && bob.log['typing:update'].at(-1).typing === false);
ok('disconnect removes presence', bob.log['presence:update'].at(-1).users.map((u) => u.name).join() === 'Bob');

const bob2 = await client('bob'); await join(bob2, B1);
await sleep(30);
ok('second tab of same user: still one entry', bob.log['presence:update'].at(-1).users.length === 1);
const n = bob.log['presence:update'].length;
bob2.disconnect(); await sleep(60);
ok('closing one tab does not drop user', bob.log['presence:update'].length === n);

// 7. leave + kick
bob.emit('board:leave', { boardId: B1 }); await sleep(30);
emitToBoard(fakeReq(undefined), 'card:deleted', { cardId: 'z' }); await sleep(50);
ok('after board:leave no more events', !bob.log['card:deleted']);
const bob3 = await client('bob'); await join(bob3, B1);
const dropped = new Promise((r) => bob3.on('disconnect', r));
kickUser('u2');
ok('kickUser disconnects live sockets', !!(await Promise.race([dropped, sleep(500).then(() => false)])));

console.log(fails ? `\n${fails} FAILED` : '\nall passed');
process.exit(fails ? 1 : 0);
